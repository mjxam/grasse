/*
  # Add Multiple Images Support for Products

  ## Changes
  1. Schema Changes
    - Add `images` column (jsonb array) to store multiple product images
    - Keep `image` column for backward compatibility as primary image
  
  2. Data Migration
    - Update existing products to use images array format
  
  ## Notes
  - The `images` array will store all product image URLs
  - The first image in the array is considered the primary image
*/

-- Add images column to store array of image URLs
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'images'
  ) THEN
    ALTER TABLE products ADD COLUMN images jsonb DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- Migrate existing single image to images array
UPDATE products 
SET images = jsonb_build_array(image)
WHERE images = '[]'::jsonb AND image IS NOT NULL;