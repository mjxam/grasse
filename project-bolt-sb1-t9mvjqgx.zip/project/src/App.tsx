import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { MessageCircle, ShoppingCart } from 'lucide-react';
import Header from './components/Header';
import Footer from './components/Footer';
import Cart from './components/Cart';
import LoadingScreen from './components/LoadingScreen';
import Home from './pages/Home';
import Perfumes from './pages/Perfumes';
import Incenses from './pages/Essences';
import AirFresheners from './pages/AirFresheners';
import Ouds from './pages/Ouds';
import ProductDetail from './pages/ProductDetail';
import AboutUs from './pages/AboutUs';
import ContactUs from './pages/ContactUs';
import Fav from './pages/Fav';
import { Product } from './components/ProductCard';

interface CartItem extends Product {
  quantity: number;
}

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [favoriteItems, setFavoriteItems] = useState<Product[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [showFloatingCart, setShowFloatingCart] = useState(false);
  const [showFloatingFav, setShowFloatingFav] = useState(false);
  const [favTimeout, setFavTimeout] = useState<NodeJS.Timeout | null>(null);
  const [cartTimeout, setCartTimeout] = useState<NodeJS.Timeout | null>(null);

  // Loading screen effect
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  // Show/hide floating cart based on cart items and scroll position
  useEffect(() => {
    const hasItems = cartItems.length > 0;

    // Don't show floating cart if cart drawer is open
    if (isCartOpen) {
      setShowFloatingCart(false);
      return;
    }

    if (hasItems) {
      // Show cart bubble immediately when items are added
      setShowFloatingCart(true);

      // Clear existing timeout
      if (cartTimeout) {
        clearTimeout(cartTimeout);
      }

      // Auto-hide after 3 seconds if user is at top of page
      const scrolled = window.scrollY > 100;
      if (!scrolled) {
        const newTimeout = setTimeout(() => {
          setShowFloatingCart(false);
        }, 3000);
        setCartTimeout(newTimeout);
      }
    } else {
      // Hide cart bubble immediately when cart is empty
      setShowFloatingCart(false);
    }
  }, [cartItems.length, isCartOpen]);

  // Scroll detection for floating cart
  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.scrollY > 100;
      const hasItems = cartItems.length > 0;

      // Don't show floating cart if cart drawer is open
      if (isCartOpen) {
        setShowFloatingCart(false);
        return;
      }

      // Clear any auto-hide timeout when scrolling
      if (cartTimeout) {
        clearTimeout(cartTimeout);
        setCartTimeout(null);
      }

      setShowFloatingCart(scrolled && hasItems);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (cartTimeout) {
        clearTimeout(cartTimeout);
      }
    };
  }, [cartItems.length, cartTimeout, isCartOpen]);

  // Cart functions
  const addToCart = (product: Product) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === product.id);
      if (existingItem) {
        return prevItems.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevItems, { ...product, quantity: 1 }];
    });
  };

  const updateCartQuantity = (id: number, quantity: number) => {
    if (quantity === 0) {
      removeFromCart(id);
    } else {
      setCartItems(prevItems =>
        prevItems.map(item =>
          item.id === id ? { ...item, quantity } : item
        )
      );
    }
  };

  const removeFromCart = (id: number) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== id));
  };

  const getTotalCartItems = () => {
    return cartItems.reduce((total, item) => total + item.quantity, 0);
  };

  // Favorites functions
  const toggleFavorite = (product: Product) => {
    setFavoriteItems(prevFavorites => {
      const isFavorite = prevFavorites.some(fav => fav.id === product.id);
      if (isFavorite) {
        return prevFavorites.filter(fav => fav.id !== product.id);
      } else {
        // Show floating fav button when item is added
        const scrolled = window.scrollY > 100;
        if (scrolled) {
          setShowFloatingFav(true);
          
          // Clear existing timeout
          if (favTimeout) {
            clearTimeout(favTimeout);
          }
          
          // Set new timeout to hide after 3 seconds
          const newTimeout = setTimeout(() => {
            setShowFloatingFav(false);
          }, 3000);
          setFavTimeout(newTimeout);
        }
        
        return [...prevFavorites, product];
      }
    });
  };

  const isFavorite = (productId: number) => {
    return favoriteItems.some(fav => fav.id === productId);
  };

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <Router>
      <div className="min-h-screen bg-white">
        <Header 
          cartItemsCount={getTotalCartItems()} 
          onCartClick={() => setIsCartOpen(true)} 
        />
        
        <main>
          <Routes>
            <Route 
              path="/" 
              element={
                <Home 
                  onAddToCart={addToCart}
                  onToggleFavorite={toggleFavorite}
                  isFavorite={isFavorite}
                />
              } 
            />
            <Route 
              path="/perfumes" 
              element={
                <Perfumes 
                  onAddToCart={addToCart}
                  onToggleFavorite={toggleFavorite}
                  isFavorite={isFavorite}
                />
              } 
            />
            <Route 
              path="/incenses"
              element={
                <Incenses 
                  onAddToCart={addToCart}
                  onToggleFavorite={toggleFavorite}
                  isFavorite={isFavorite}
                />
              } 
            />
            <Route
              path="/air-fresheners"
              element={
                <AirFresheners
                  onAddToCart={addToCart}
                  onToggleFavorite={toggleFavorite}
                  isFavorite={isFavorite}
                />
              }
            />
            <Route
              path="/ouds"
              element={
                <Ouds
                  onAddToCart={addToCart}
                  onToggleFavorite={toggleFavorite}
                  isFavorite={isFavorite}
                />
              }
            />
            <Route
              path="/product/:id"
              element={
                <ProductDetail
                  onAddToCart={addToCart}
                  onToggleFavorite={toggleFavorite}
                  isFavorite={isFavorite}
                />
              }
            />
            <Route path="/about-us" element={<AboutUs />} />
            <Route path="/contact-us" element={<ContactUs />} />
            <Route 
              path="/fav" 
              element={
                <Fav 
                  favoriteItems={favoriteItems}
                  onAddToCart={addToCart}
                  onToggleFavorite={toggleFavorite}
                  isFavorite={isFavorite}
                />
              } 
            />
          </Routes>
        </main>

        <Footer />

        <Cart
          isOpen={isCartOpen}
          onClose={() => setIsCartOpen(false)}
          items={cartItems}
          onUpdateQuantity={updateCartQuantity}
          onRemoveItem={removeFromCart}
        />

        {/* Floating Cart Button */}
        {showFloatingCart && (
          <button
            onClick={() => setIsCartOpen(true)}
            className={`fixed top-6 right-6 z-50 bg-gradient-to-r from-gold-600 to-gold-700 text-white p-3 rounded-full shadow-lg hover:from-gold-700 hover:to-gold-800 transition-all transform hover:scale-110 duration-500 ${
              showFloatingCart 
                ? 'opacity-100 scale-100 translate-y-0' 
                : 'opacity-0 scale-75 translate-y-4'
            }`}
          >
            <ShoppingCart className="h-5 w-5" />
            {getTotalCartItems() > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center font-bold">
                {getTotalCartItems()}
              </span>
            )}
          </button>
        )}

        {/* Floating Favorites Button */}
        {showFloatingFav && favoriteItems.length > 0 && (
          <button
            onClick={() => window.location.href = '/fav'}
            className={`fixed top-6 right-20 z-50 bg-gradient-to-r from-red-500 to-red-600 text-white p-3 rounded-full shadow-lg hover:from-red-600 hover:to-red-700 transition-all transform hover:scale-110 duration-500 ${
              showFloatingFav 
                ? 'opacity-100 scale-100 translate-y-0' 
                : 'opacity-0 scale-75 translate-y-4'
            }`}
          >
            <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
            </svg>
            {favoriteItems.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-gold-600 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center font-bold">
                {favoriteItems.length}
              </span>
            )}
          </button>
        )}

        {/* WhatsApp Floating Button */}
        <a
          href="https://wa.me/1234567890"
          target="_blank"
          rel="noopener noreferrer"
          className="fixed bottom-6 right-6 z-50 bg-green-500 text-white p-4 rounded-full shadow-lg hover:bg-green-600 transition-all transform hover:scale-110"
        >
          <MessageCircle className="h-6 w-6" />
        </a>
      </div>
    </Router>
  );
}

export default App;