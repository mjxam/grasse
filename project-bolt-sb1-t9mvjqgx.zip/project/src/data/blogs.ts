export interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  readTime: string;
  image: string;
  category: string;
  tags: string[];
}

export const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "The Art of Layering Fragrances: Creating Your Signature Scent",
    excerpt: "Discover the secrets of professional perfumers and learn how to layer different fragrances to create a unique scent that's entirely your own.",
    content: "Fragrance layering is an ancient art that allows you to create a personalized scent profile...",
    author: "Marie Dubois",
    date: "2025-01-15",
    readTime: "5 min read",
    image: "https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=800",
    category: "Tips & Techniques",
    tags: ["layering", "perfume", "signature scent"]
  },
  {
    id: 2,
    title: "Understanding Fragrance Notes: Top, Middle, and Base",
    excerpt: "Learn about the three-tier structure of perfumes and how each note contributes to the overall fragrance experience throughout the day.",
    content: "Every great perfume tells a story through its carefully orchestrated notes...",
    author: "Antoine Laurent",
    date: "2025-01-12",
    readTime: "7 min read",
    image: "https://images.pexels.com/photos/1961795/pexels-photo-1961795.jpeg?auto=compress&cs=tinysrgb&w=800",
    category: "Education",
    tags: ["fragrance notes", "perfume basics", "education"]
  },
  {
    id: 3,
    title: "Seasonal Scents: Choosing the Perfect Fragrance for Every Season",
    excerpt: "Explore how different seasons call for different fragrance families and learn to build a versatile fragrance wardrobe.",
    content: "Just as we change our clothing with the seasons, our fragrance choices should evolve too...",
    author: "Isabella Chen",
    date: "2025-01-10",
    readTime: "6 min read",
    image: "https://images.pexels.com/photos/1190829/pexels-photo-1190829.jpeg?auto=compress&cs=tinysrgb&w=800",
    category: "Seasonal Guide",
    tags: ["seasonal", "fragrance wardrobe", "guide"]
  },
  {
    id: 4,
    title: "The Psychology of Scent: How Fragrances Affect Mood and Memory",
    excerpt: "Delve into the fascinating connection between scent, emotion, and memory, and discover how to use fragrance to enhance your daily life.",
    content: "The human sense of smell is directly connected to the limbic system...",
    author: "Dr. Sarah Williams",
    date: "2025-01-08",
    readTime: "8 min read",
    image: "https://images.pexels.com/photos/3870362/pexels-photo-3870362.jpeg?auto=compress&cs=tinysrgb&w=800",
    category: "Science",
    tags: ["psychology", "mood", "memory", "science"]
  },
  {
    id: 5,
    title: "Essential Oils vs. Synthetic Fragrances: What's the Difference?",
    excerpt: "Understand the pros and cons of natural essential oils versus synthetic fragrances in modern perfumery.",
    content: "The debate between natural and synthetic ingredients in perfumery is as old as modern fragrance itself...",
    author: "Marie Dubois",
    date: "2025-01-05",
    readTime: "6 min read",
    image: "https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&w=800",
    category: "Ingredients",
    tags: ["essential oils", "synthetic", "ingredients", "natural"]
  },
  {
    id: 6,
    title: "Caring for Your Fragrance Collection: Storage and Longevity Tips",
    excerpt: "Learn the best practices for storing your precious fragrances to maintain their quality and extend their lifespan.",
    content: "Proper storage is crucial for maintaining the integrity of your fragrance collection...",
    author: "Antoine Laurent",
    date: "2025-01-03",
    readTime: "4 min read",
    image: "https://images.pexels.com/photos/6621418/pexels-photo-6621418.jpeg?auto=compress&cs=tinysrgb&w=800",
    category: "Care & Maintenance",
    tags: ["storage", "care", "longevity", "maintenance"]
  }
];