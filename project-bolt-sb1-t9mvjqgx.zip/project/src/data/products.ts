import { Product } from '../components/ProductCard';

export interface ProductWithFilters extends Product {
  gender: 'men' | 'women' | 'unisex';
  priceRange: 'budget' | 'mid' | 'luxury';
}
export const perfumes: ProductWithFilters[] = [
  {
    id: 1,
    name: "Cannes",
    category: "Perfume",
    price: 210.00,
    image: "/products/cannes/A7402600.jpg",
    images: [
      "/products/cannes/A7402600.jpg",
      "/products/cannes/A7402623.jpg",
      "/products/cannes/A7402677.jpg",
      "/products/cannes/A7402680.jpg"
    ],
    description: "Jasmine with coconut and tobacco… a blend that tells a story of luxury. For soirées that last in memory.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'luxury'
  },
  {
    id: 2,
    name: "Lorient",
    category: "Perfume",
    price: 210.00,
    image: "/products/lorient/A7402601.jpg",
    images: [
      "/products/lorient/A7402601.jpg",
      "/products/lorient/A7402626.jpg",
      "/products/lorient/A7402673.jpg",
      "/products/lorient/9f842c3e-215a-473e-98d1-b6ab5b4be79e.jpg"
    ],
    description: "Marshmallow and freesia with oud and patchouli, crowned by dark chocolate… a lavish sweetness with bold. For nights that call for a fragrance melting like chocolate… irresistible soft boldness.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'luxury'
  },
  {
    id: 3,
    name: "No Way",
    category: "Perfume",
    price: 420.00,
    image: "/products/no-way/A7402489.jpg",
    images: ["/products/no-way/A7402489.jpg"],
    description: "Pink pepper and clove with vanilla and amber… irresistible boldness. Perfect for nights of mystery and allure.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'luxury'
  },
  {
    id: 4,
    name: "Real Summer",
    category: "Perfume",
    price: 210.00,
    image: "/products/real-summer/A7402608.jpg",
    images: [
      "/products/real-summer/A7402608.jpg",
      "/products/real-summer/A7402627.jpg",
      "/products/real-summer/A7402675.jpg",
      "/products/real-summer/A7402520.jpg"
    ],
    description: "Lemon and mint blending with soft jasmine and a hint of ginger… a summer alive with vitality. For sunlit days when you seek refreshing energy with graceful elegance.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'luxury'
  },
  {
    id: 5,
    name: "Season",
    category: "Perfume",
    price: 420.00,
    image: "/products/season/A7402583.jpg",
    images: [
      "/products/season/A7402583.jpg",
      "/products/season/A7402487.jpg",
      "/products/season/A7402517.jpg",
      "/products/season/A7402665.jpg",
      "/products/season/A7402632.jpg"
    ],
    description: "Tobacco, nutmeg, saffron, and sandalwood… the power of seasons. For nights when your presence should be declared without apology.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'luxury'
  },
  {
    id: 6,
    name: "Storm",
    category: "Perfume",
    price: 375.00,
    image: "/products/storm/A7402612.jpg",
    images: [
      "/products/storm/A7402612.jpg",
      "/products/storm/A7402634 (2).jpg",
      "/products/storm/A7402514.jpg",
      "/products/storm/A7402656_1.jpg"
    ],
    description: "Natural oud blended with rare French oils… where East meets West. Made for occasions that demand a commanding presence.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'luxury'
  },
  {
    id: 7,
    name: "Touch Of Me",
    category: "Perfume",
    price: 365.00,
    image: "/products/touch-of-me/A7402490.jpg",
    images: [
      "/products/touch-of-me/A7402490.jpg",
      "/products/touch-of-me/A7402523.jpg",
      "/products/touch-of-me/A7402605.jpg",
      "/products/touch-of-me/A7402629.jpg",
      "/products/touch-of-me/A7402669.jpg"
    ],
    description: "Fig and jasmine with amber musk… a touch that lingers. For dreamy mornings and intimate moments.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'luxury'
  },
  {
    id: 8,
    name: "Kashkha",
    category: "Perfume",
    price: 420.00,
    image: "/products/kashkha/A7402611.jpg",
    images: [
      "/products/kashkha/A7402611.jpg",
      "/products/kashkha/A7402636.jpg",
      "/products/kashkha/A7402666.jpg",
      "/products/kashkha/A7402526.jpg"
    ],
    description: "Cinnamon and saffron over oud… luxury in every breath. For winter nights made for prestige.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'luxury'
  }
];

export const incenses: ProductWithFilters[] = [
  {
    id: 101,
    name: "Dokhon Abudhabi",
    category: "Incense",
    price: 265.00,
    image: "/products/dokhon-abudhabi/A7402696.jpg",
    images: [
      "/products/dokhon-abudhabi/A7402696.jpg",
      "/products/dokhon-abudhabi/A7402698.jpg",
      "/products/dokhon-abudhabi/A7402688.jpg"
    ],
    description: "Cypress and mandarin entwined with incense and jasmine… a incense that narrates a city. For celebrations that blend heritage and modernity in one moment.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'luxury'
  },
  {
    id: 102,
    name: "Dokhon Alain",
    category: "Incense",
    price: 210.00,
    image: "/products/dokhon-alain/A7402697.jpg",
    images: [
      "/products/dokhon-alain/A7402697.jpg",
      "/products/dokhon-alain/A7402703.jpg",
      "/products/dokhon-alain/A7402683.jpg"
    ],
    description: "Saffron and bergamot over oud and leather… incense breathing luxury. For evenings where you leave a mark before saying a word.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'luxury'
  }
];

export const airFresheners: ProductWithFilters[] = [
  {
    id: 201,
    name: "No Way Air Freshener",
    category: "Air Freshener",
    price: 200.00,
    image: "/products/no-way/A7402710.jpg",
    images: [
      "/products/no-way/A7402710.jpg"
    ],
    description: "Clove and pink pepper with amber and musk… air that defies the ordinary. For offices or rooms that demand a touch of refined rebellion.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'mid'
  },
  {
    id: 202,
    name: "Season Air Freshener",
    category: "Air Freshener",
    price: 200.00,
    image: "/products/season/A7402713.jpg",
    images: [
      "/products/season/A7402713.jpg"
    ],
    description: "Tobacco and nutmeg with leather and sandalwood… air with the strength of seasons. For spaces that should announce your presence before you even arrive.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'mid'
  },
  {
    id: 203,
    name: "Touch Of Me Air Freshener",
    category: "Air Freshener",
    price: 200.00,
    image: "/products/touch-of-me/A7402714.jpg",
    images: [
      "/products/touch-of-me/A7402714.jpg"
    ],
    description: "Fig and jasmine with musk and amber… warmth that fills your bed with luxury. Winter nights whispering romance.",
    rating: 5.0,
    gender: 'unisex',
    priceRange: 'mid'
  }
];

export const ouds: ProductWithFilters[] = [];