import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Clock, Send } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const ContactUs: React.FC = () => {
  const [heroRef, isHeroVisible] = useScrollAnimation(0.1);
  const [formRef, isFormVisible] = useScrollAnimation(0.1);
  const [infoRef, isInfoVisible] = useScrollAnimation(0.1);

  return (
    <>
      {/* Hero Section */}
      <section className="relative text-white overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Contact us - luxury fragrance consultation"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div 
            ref={heroRef}
            className={`text-center transition-all duration-1000 ${
              isHeroVisible 
                ? 'opacity-100 transform translate-y-0' 
                : 'opacity-0 transform translate-y-8'
            }`}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-gold-600 to-gold-700 bg-clip-text text-transparent overflow-visible">
                Contact Us
              </span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
              Get in touch with our fragrance experts. We're here to help you find your perfect scent 
              or answer any questions about our luxury collection.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div 
              ref={formRef}
              className={`transition-all duration-1000 ${
                isFormVisible 
                  ? 'opacity-100 transform translate-x-0' 
                  : 'opacity-0 transform -translate-x-12'
              }`}
            >
              <div className="bg-gray-50 rounded-2xl p-8 border border-gray-200">
                <h2 className="text-3xl font-bold text-gold-600 mb-6">Send us a Message</h2>
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        First Name
                      </label>
                      <input
                        type="text"
                        className="w-full px-4 py-3 bg-white border border-gray-300 rounded-lg focus:outline-none focus:border-gold-600 transition-colors"
                        placeholder="Your first name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Last Name
                      </label>
                      <input
                        type="text"
                        className="w-full px-4 py-3 bg-white border border-gray-300 rounded-lg focus:outline-none focus:border-gold-600 transition-colors"
                        placeholder="Your last name"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      className="w-full px-4 py-3 bg-white border border-gray-300 rounded-lg focus:outline-none focus:border-gold-600 transition-colors"
                      placeholder="your.email@example.com"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      className="w-full px-4 py-3 bg-white border border-gray-300 rounded-lg focus:outline-none focus:border-gold-600 transition-colors"
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Subject
                    </label>
                    <select className="w-full px-4 py-3 bg-white border border-gray-300 rounded-lg focus:outline-none focus:border-gold-600 transition-colors">
                      <option>General Inquiry</option>
                      <option>Product Information</option>
                      <option>Wholesale</option>
                      <option>Support</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Message
                    </label>
                    <textarea
                      rows={5}
                      className="w-full px-4 py-3 bg-white border border-gray-300 rounded-lg focus:outline-none focus:border-gold-600 transition-colors resize-none"
                      placeholder="Tell us how we can help you..."
                    ></textarea>
                  </div>
                  
                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-gold-600 to-gold-700 text-white py-4 rounded-full font-semibold hover:from-gold-700 hover:to-gold-800 transition-all transform hover:scale-105 shadow-lg hover:shadow-gold-600/25 flex items-center justify-center space-x-2"
                  >
                    <Send className="h-5 w-5" />
                    <span>Send Message</span>
                  </button>
                </form>
              </div>
            </div>

            {/* Contact Information */}
            <div 
              ref={infoRef}
              className={`transition-all duration-1000 delay-200 ${
                isInfoVisible 
                  ? 'opacity-100 transform translate-x-0' 
                  : 'opacity-0 transform translate-x-12'
              }`}
            >
              <h2 className="text-3xl font-bold text-gold-600 mb-8">Get in Touch</h2>
              
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center flex-shrink-0">
                    <MapPin className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 mb-2">Visit Our Stores</h3>
                    <div className="text-gray-600 space-y-1">
                      <p>Experience our perfumes, incenses, and air fresheners in person</p>
                      <a 
                        href="https://maps.app.goo.gl/83sf9KMDKuGzgDFH9" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="block hover:text-gold-600 transition-colors cursor-pointer"
                      >
                        Dalma Mall, Abu Dhabi
                      </a>
                      <a 
                        href="https://maps.app.goo.gl/83sf9KMDKuGzgDFH9" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="block hover:text-gold-600 transition-colors cursor-pointer"
                      >
                        Galeria Mall, Abu Dhabi
                      </a>
                      <a 
                        href="https://maps.app.goo.gl/83sf9KMDKuGzgDFH9" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="block hover:text-gold-600 transition-colors cursor-pointer"
                      >
                        Marina Mall, Abu Dhabi
                      </a>
                      <a 
                        href="https://maps.app.goo.gl/83sf9KMDKuGzgDFH9" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="block hover:text-gold-600 transition-colors cursor-pointer"
                      >
                        Bawadi Mall, Abu Dhabi
                      </a>
                      <a 
                        href="https://maps.app.goo.gl/83sf9KMDKuGzgDFH9" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="block hover:text-gold-600 transition-colors cursor-pointer"
                      >
                        Bawabat Al Sharq Mall, Abu Dhabi
                      </a>
                    </div>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center flex-shrink-0">
                    <Phone className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 mb-2">Call Us</h3>
                    <div className="text-gray-600 space-y-1">
                      <p>+971 2 123 4567</p>
                      <p>+971 50 123 4567</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center flex-shrink-0">
                    <Mail className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 mb-2">Email Us</h3>
                    <div className="text-gray-600 space-y-1">
                      <p>info@grasse.ae</p>
                      <p>support@grasse.ae</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center flex-shrink-0">
                    <Clock className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 mb-2">Business Hours</h3>
                    <div className="text-gray-600 space-y-1">
                      <p>Sunday - Thursday: 10:00 AM - 10:00 PM</p>
                      <p>Friday - Saturday: 10:00 AM - 11:00 PM</p>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactUs;