import React from 'react';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import Hero from '../components/Hero';
import ProductSection from '../components/ProductSection';
import { perfumes, incenses, airFresheners, ouds } from '../data/products';
import { Product } from '../components/ProductCard';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

interface HomeProps {
  onAddToCart: (product: Product) => void;
  onToggleFavorite: (product: Product) => void;
  isFavorite: (productId: number) => boolean;
}

const Home: React.FC<HomeProps> = ({ onAddToCart, onToggleFavorite, isFavorite }) => {
  const [storyRef, isStoryVisible] = useScrollAnimation(0.1);
  const [storyTextRef, isStoryTextVisible] = useScrollAnimation(0.2);
  const [storyImageRef, isStoryImageVisible] = useScrollAnimation(0.2);
  const [storyTitleRef, isStoryTitleVisible] = useScrollAnimation(0.1);
  const [storyStatsRef, isStoryStatsVisible] = useScrollAnimation(0.3);
  const [productsRef, isProductsVisible] = useScrollAnimation(0.1);
  const [productsImageRef, isProductsImageVisible] = useScrollAnimation(0.1);
  const [locationsRef, isLocationsVisible] = useScrollAnimation(0.1);
  const [location1Ref, isLocation1Visible] = useScrollAnimation(0.2);
  const [location2Ref, isLocation2Visible] = useScrollAnimation(0.2);
  const [location3Ref, isLocation3Visible] = useScrollAnimation(0.2);
  const [location4Ref, isLocation4Visible] = useScrollAnimation(0.2);
  const [location5Ref, isLocation5Visible] = useScrollAnimation(0.2);
  const [productsBadgeRef, isProductsBadgeVisible] = useScrollAnimation(0.1);
  const [productsTitleRef, isProductsTitleVisible] = useScrollAnimation(0.2);
  const [productsCard1Ref, isProductsCard1Visible] = useScrollAnimation(0.3);
  const [productsCard2Ref, isProductsCard2Visible] = useScrollAnimation(0.3);
  const [productsCard3Ref, isProductsCard3Visible] = useScrollAnimation(0.3);
  const [perfumesButtonRef, isPerfumesButtonVisible] = useScrollAnimation(0.3);
  const [incensesButtonRef, isIncensesButtonVisible] = useScrollAnimation(0.3);
  const [freshenersButtonRef, isFreshenersButtonVisible] = useScrollAnimation(0.3);
  const [whyChooseUsRef, isWhyChooseUsVisible] = useScrollAnimation(0.1);
  const [whyChooseUsTextRef, isWhyChooseUsTextVisible] = useScrollAnimation(0.2);
  const [whyChooseUsImageRef, isWhyChooseUsImageVisible] = useScrollAnimation(0.2);
  const [faqRef, isFaqVisible] = useScrollAnimation(0.1);
  const [faqImageRef, isFaqImageVisible] = useScrollAnimation(0.2);
  const [faqContentRef, isFaqContentVisible] = useScrollAnimation(0.2);
  const [faqTitleRef, isFaqTitleVisible] = useScrollAnimation(0.1);

  // FAQ Component
  const FAQItem: React.FC<{ question: string; answer: string }> = ({ question, answer }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
      <div className="border-b border-gray-200 last:border-b-0">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full text-left flex items-center justify-between py-6 hover:text-gold-600 transition-colors"
        >
          <h3 className="text-lg font-semibold text-gray-900">{question}</h3>
          {isOpen ? (
            <ChevronUp className="h-5 w-5 text-gold-600 flex-shrink-0" />
          ) : (
            <ChevronDown className="h-5 w-5 text-gray-400 flex-shrink-0" />
          )}
        </button>
        {isOpen && (
          <div className="pb-6">
            <p className="text-gray-600 leading-relaxed">{answer}</p>
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      <Hero />
      
      {/* Company Story Section */}
      <section className="py-20 bg-#ffffff">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div 
            ref={storyRef}
            className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
          >
            {/* Story Content - Left Side */}
            <div 
              ref={storyTextRef}
              className={`space-y-6 transition-all duration-1000 ease-out ${
                isStoryTextVisible 
                  ? 'opacity-100 transform translate-x-0' 
                  : 'opacity-0 transform -translate-x-12'
              }`}
            >
              <div 
                ref={storyTitleRef}
                className={`inline-block transition-all duration-800 ${
                  isStoryTitleVisible 
                    ? 'opacity-100 transform translate-y-0' 
                    : 'opacity-0 transform translate-y-4'
                }`}
              >
                <span className="text-sm font-semibold text-gold-600 uppercase tracking-wider bg-gold-50 px-3 py-1 rounded-full border border-gold-200">
                  Our Origin
                </span>
              </div>
              
              <h2 
                className={`text-4xl md:text-5xl font-bold leading-tight transition-all duration-1000 delay-200 ${
                  isStoryTitleVisible 
                    ? 'opacity-100 transform translate-y-0' 
                    : 'opacity-0 transform translate-y-6'
                }`}
              >
                <span className="text-gray-900 overflow-visible">Our Journey of</span>
                <span className="block bg-gradient-to-r from-gold-600 to-gold-700 bg-clip-text text-transparent overflow-visible">
                  Excellence
                </span>
              </h2>
              
              <div 
                className={`space-y-4 text-gray-600 text-lg leading-relaxed transition-all duration-1000 delay-400 ${
                  isStoryTextVisible 
                    ? 'opacity-100 transform translate-y-0' 
                    : 'opacity-0 transform translate-y-8'
                }`}
              >
                <p>
                  It started its first steps in 2019 and achieved great success among the successful perfume brands 
                  and proved its presence in the Emirati perfume market in a short time.
                </p>
              </div>
            </div>

            {/* Story Image - Right Side */}
            <div 
              ref={storyImageRef}
              className={`relative transition-all duration-1000 ease-out delay-200 ${
                isStoryImageVisible 
                  ? 'opacity-100 transform translate-x-0' 
                  : 'opacity-0 transform translate-x-12'
              }`}
            >
              <div className="relative overflow-hidden rounded-2xl shadow-2xl" style={{ height: '600px' }}>
                <img 
                  src="https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=800" 
                  alt="Master perfumer crafting luxury perfumes"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
                
                {/* Floating Elements */}
                <div className="absolute top-6 right-6 bg-white/90 backdrop-blur-sm rounded-full p-3 border border-amber-200">
                  <div className="text-gold-600 text-sm font-semibold">Est. 1985</div>
                </div>
                
                <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur-sm rounded-xl p-4 border border-amber-200 max-w-xs">
                  <div className="text-white text-sm font-medium mb-1">Marie Dubois</div>
                  <div className="text-gold-600 text-xs">Founder & Master Perfumer</div>
                </div>
              </div>
              
              {/* Decorative Elements */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-br from-gold-200/40 to-gold-300/40 rounded-full blur-xl"></div>
              <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-gradient-to-br from-gold-300/40 to-gold-200/40 rounded-full blur-xl"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Products Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start"
          >
            {/* Product Image - Left Side */}
            <div
              ref={productsImageRef}
              className={`relative transition-all duration-1000 ease-out ${
                isProductsImageVisible
                  ? 'opacity-100 transform translate-x-0'
                  : 'opacity-0 transform -translate-x-12'
              }`}
            >
              <div className="relative overflow-hidden rounded-2xl shadow-2xl" style={{ height: '620px' }}>
                <img
                  src="https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Luxury fragrance collection showcasing our product lines"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>

                {/* Floating Elements */}
                <div className="absolute top-6 right-6 bg-white/90 backdrop-blur-sm rounded-full p-3 border border-amber-200">
                  <div className="text-gold-600 text-sm font-semibold">Premium</div>
                </div>

                <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur-sm rounded-xl p-4 border border-amber-200 max-w-xs">
                  <div className="text-gray-900 text-sm font-medium mb-1">Three Collections</div>
                  <div className="text-gold-600 text-xs">Fragrances • Intense • Oud</div>
                </div>
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-gradient-to-br from-gold-200/40 to-gold-300/40 rounded-full blur-xl"></div>
              <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-br from-gold-300/40 to-gold-200/40 rounded-full blur-xl"></div>
            </div>

            {/* Product Content - Right Side */}
            <div className="space-y-6">
              <div
                ref={productsBadgeRef}
                className={`inline-block transition-all duration-1000 ease-out ${
                  isProductsBadgeVisible
                    ? 'opacity-100 transform translate-x-0'
                    : 'opacity-0 transform translate-x-12'
                }`}
              >
                <span className="text-sm font-semibold text-gold-600 uppercase tracking-wider bg-gold-50 px-3 py-1 rounded-full border border-gold-200">
                  Our Collections
                </span>
              </div>

              <h2
                ref={productsTitleRef}
                className={`text-4xl md:text-5xl font-bold leading-tight transition-all duration-1000 ease-out delay-200 ${
                  isProductsTitleVisible
                    ? 'opacity-100 transform translate-x-0'
                    : 'opacity-0 transform translate-x-12'
                }`}
              >
                <span className="text-gray-900 overflow-visible">Our</span>
                <span className="block bg-gradient-to-r from-gold-600 to-gold-700 bg-clip-text text-transparent overflow-visible">
                  Products
                </span>
              </h2>

              <div className="space-y-4 text-gray-600 text-lg leading-relaxed">
                <div
                  ref={productsCard1Ref}
                  className={`bg-gray-50 rounded-xl p-5 border border-gray-200 transition-all duration-1000 ease-out delay-400 ${
                    isProductsCard1Visible
                      ? 'opacity-100 transform translate-x-0'
                      : 'opacity-0 transform translate-x-12'
                  }`}
                >
                  <h3 className="text-lg font-bold text-gold-600 mb-2">Our Fragrances</h3>
                  <p className="text-base">
                    Represents: <span className="font-semibold text-gray-900">luxury</span> –
                    <span className="font-semibold text-gray-900">unique taste</span> –
                    <span className="font-semibold text-gray-900">excellence</span>
                  </p>
                </div>

                <div
                  ref={productsCard2Ref}
                  className={`bg-gray-50 rounded-xl p-5 border border-gray-200 transition-all duration-1000 ease-out delay-500 ${
                    isProductsCard2Visible
                      ? 'opacity-100 transform translate-x-0'
                      : 'opacity-0 transform translate-x-12'
                  }`}
                >
                  <h3 className="text-lg font-bold text-gold-600 mb-2">Our Incense</h3>
                  <p className="text-base">
                    Represents the <span className="font-semibold text-gray-900">warmth of our Arab homes</span> in all their occasions and time.
                  </p>
                </div>

                <div
                  ref={productsCard3Ref}
                  className={`bg-gray-50 rounded-xl p-5 border border-gray-200 transition-all duration-1000 ease-out delay-600 ${
                    isProductsCard3Visible
                      ? 'opacity-100 transform translate-x-0'
                      : 'opacity-0 transform translate-x-12'
                  }`}
                >
                  <h3 className="text-lg font-bold text-gold-600 mb-2">The Oud</h3>
                  <p className="text-base">
                    Represents the <span className="font-semibold text-gray-900">fragrance of the Arab heritage</span> in our societies.
                  </p>
                </div>

                <div
                  className={`bg-gray-50 rounded-xl p-5 border border-gray-200 transition-all duration-1000 ease-out delay-700 ${
                    isProductsCard3Visible
                      ? 'opacity-100 transform translate-x-0'
                      : 'opacity-0 transform translate-x-12'
                  }`}
                >
                  <h3 className="text-lg font-bold text-gold-600 mb-2">Our Air Freshener</h3>
                  <p className="text-base">
                    Represents the <span className="font-semibold text-gray-900">family memories</span> wherever you are and feels you home.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div 
            ref={whyChooseUsRef}
            className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
          >
            {/* Text Content - Left Side */}
            <div 
              ref={whyChooseUsTextRef}
              className={`space-y-6 transition-all duration-1000 ease-out ${
                isWhyChooseUsTextVisible 
                  ? 'opacity-100 transform translate-x-0' 
                  : 'opacity-0 transform -translate-x-12'
              }`}
            >
              <div className="mb-6">
                <span className="text-sm font-semibold text-gold-600 uppercase tracking-wider bg-gold-50 px-3 py-1 rounded-full border border-gold-200">
                  Excellence
                </span>
              </div>
              
              <h2 className="text-4xl md:text-5xl font-bold leading-tight">
                <span className="text-gray-900 overflow-visible">Why Choose</span>
                <span className="block bg-gradient-to-r from-gold-600 to-gold-700 bg-clip-text text-transparent overflow-visible">
                  Us?
                </span>
              </h2>
              
              <p className="text-gray-900 text-lg leading-relaxed mb-8">
                With over four decades of expertise in luxury fragrance creation, Grasse combines 
                traditional French perfumery techniques with modern innovation. Our master perfumers 
                hand-craft each fragrance using only the finest ingredients sourced from around the world, 
                ensuring every bottle delivers an unforgettable olfactory experience that defines your unique personality.
              </p>
              
              <Link 
                to="/contact-us"
               onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className="inline-block bg-gradient-to-r from-gold-600 to-gold-700 text-white px-8 py-4 rounded-full font-semibold hover:from-gold-700 hover:to-gold-800 transition-all transform hover:scale-105 shadow-lg hover:shadow-gold-600/25"
              >
                Contact Us
              </Link>
            </div>

            {/* Image - Right Side */}
            <div 
              ref={whyChooseUsImageRef}
              className={`relative transition-all duration-1000 ease-out delay-200 ${
                isWhyChooseUsImageVisible 
                  ? 'opacity-100 transform translate-x-0' 
                  : 'opacity-0 transform translate-x-12'
              }`}
            >
              <div className="relative overflow-hidden rounded-2xl shadow-2xl" style={{ height: '600px' }}>
                <img 
                  src="https://images.pexels.com/photos/1961795/pexels-photo-1961795.jpeg?auto=compress&cs=tinysrgb&w=800" 
                  alt="Luxury fragrance craftsmanship and quality"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
              </div>
              
              {/* Decorative Elements */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-br from-gold-200/40 to-gold-300/40 rounded-full blur-xl"></div>
              <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-gradient-to-br from-gold-300/40 to-gold-200/40 rounded-full blur-xl"></div>
            </div>
          </div>
        </div>
      </section>


      <ProductSection
        id="perfumes"
        title="Premium Perfumes"
        description="Discover our collection of luxury fragrances, each crafted to tell your unique story through scent."
        products={perfumes.map(p => p.id === 3 ? perfumes.find(pr => pr.id === 6)! : p).filter((p, i, arr) => arr.findIndex(pr => pr.id === p.id) === i).slice(0, 4)}
        onAddToCart={onAddToCart}
        onToggleFavorite={onToggleFavorite}
        isFavorite={isFavorite}
        maxProducts={4}
      />

      {/* View All Perfumes Button */}
      <div className="bg-gray-50 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div 
            ref={perfumesButtonRef}
            className={`transition-all duration-1000 ease-out ${
              isPerfumesButtonVisible 
                ? 'opacity-100 transform translate-y-0 scale-100' 
                : 'opacity-0 transform translate-y-8 scale-75'
            }`}
          >
            <Link 
              to="/perfumes"
             onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="inline-block bg-gradient-to-r from-gold-600 to-gold-700 text-white px-8 py-3 rounded-full font-semibold hover:from-gold-700 hover:to-gold-800 transition-all transform hover:scale-105 shadow-lg hover:shadow-gold-600/25"
            >
              View All
            </Link>
          </div>
        </div>
      </div>

      <ProductSection
        id="incenses"
        title="Pure Incenses"
        description="Essential oils and concentrated incenses for aromatherapy, meditation, and personal wellness."
        products={incenses}
        onAddToCart={onAddToCart}
        onToggleFavorite={onToggleFavorite}
        isFavorite={isFavorite}
        maxProducts={4}
      />

      {/* View All Incenses Button */}
      <div className="bg-gray-50 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div 
            ref={incensesButtonRef}
            className={`transition-all duration-1000 ease-out ${
              isIncensesButtonVisible 
                ? 'opacity-100 transform translate-y-0 scale-100' 
                : 'opacity-0 transform translate-y-8 scale-75'
            }`}
          >
            <Link 
              to="/incenses"
             onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="inline-block bg-gradient-to-r from-gold-600 to-gold-700 text-white px-8 py-3 rounded-full font-semibold hover:from-gold-700 hover:to-gold-800 transition-all transform hover:scale-105 shadow-lg hover:shadow-gold-600/25"
            >
              View All
            </Link>
          </div>
        </div>
      </div>

      <ProductSection
        id="fresheners"
        title="Air Fresheners"
        description="Transform any space with our sophisticated air fresheners that create lasting impressions."
        products={airFresheners}
        onAddToCart={onAddToCart}
        onToggleFavorite={onToggleFavorite}
        isFavorite={isFavorite}
        maxProducts={4}
      />

      {/* View All Air Fresheners Button */}
      <div className="bg-gray-50 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div
            ref={freshenersButtonRef}
            className={`transition-all duration-1000 ease-out ${
              isFreshenersButtonVisible
                ? 'opacity-100 transform translate-y-0 scale-100'
                : 'opacity-0 transform translate-y-8 scale-75'
            }`}
          >
            <Link
              to="/air-fresheners"
             onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="inline-block bg-gradient-to-r from-gold-600 to-gold-700 text-white px-8 py-3 rounded-full font-semibold hover:from-gold-700 hover:to-gold-800 transition-all transform hover:scale-105 shadow-lg hover:shadow-gold-600/25"
            >
              View All
            </Link>
          </div>
        </div>
      </div>

      <ProductSection
        id="ouds"
        title="Premium Ouds"
        description="Discover our collection of authentic Arabian oud, crafted with the finest ingredients and traditional methods."
        products={ouds}
        onAddToCart={onAddToCart}
        onToggleFavorite={onToggleFavorite}
        isFavorite={isFavorite}
        maxProducts={4}
      />

      {/* View All Ouds Button */}
      <div className="bg-gray-50 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div
            className={`transition-all duration-1000 ease-out ${
              isFreshenersButtonVisible
                ? 'opacity-100 transform translate-y-0 scale-100'
                : 'opacity-0 transform translate-y-8 scale-75'
            }`}
          >
            <Link
              to="/ouds"
             onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="inline-block bg-gradient-to-r from-gold-600 to-gold-700 text-white px-8 py-3 rounded-full font-semibold hover:from-gold-700 hover:to-gold-800 transition-all transform hover:scale-105 shadow-lg hover:shadow-gold-600/25"
            >
              View All
            </Link>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <section className="py-32 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div 
            ref={faqRef}
            className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start"
          >
            {/* FAQ Image */}
            <div 
              ref={faqImageRef}
              className={`relative lg:sticky lg:top-8 transition-all duration-1000 ease-out ${
                isFaqImageVisible 
                  ? 'opacity-100 transform translate-x-0' 
                  : 'opacity-0 transform -translate-x-12'
              }`}
            >
              <img 
                src="https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Frequently asked questions about luxury fragrances"
                className="rounded-2xl shadow-2xl w-full h-[600px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent rounded-2xl"></div>
            </div>

            {/* FAQ Content */}
            <div 
              ref={faqContentRef}
              className={`transition-all duration-1000 ease-out delay-200 ${
                isFaqContentVisible 
                  ? 'opacity-100 transform translate-x-0' 
                  : 'opacity-0 transform translate-x-12'
              }`}
            >
              <div 
                ref={faqTitleRef}
                className={`mb-8 transition-all duration-800 ${
                  isFaqTitleVisible 
                    ? 'opacity-100 transform translate-y-0' 
                    : 'opacity-0 transform translate-y-4'
                }`}
              >
                <h2 
                  className={`text-4xl font-bold text-gold-600 mb-4 transition-all duration-1000 delay-200 ${
                    isFaqTitleVisible 
                      ? 'opacity-100 transform translate-y-0' 
                      : 'opacity-0 transform translate-y-6'
                  }`}
                >
                  Frequently Asked Questions
                </h2>
                <p 
                  className={`text-lg text-gray-600 transition-all duration-1000 delay-400 ${
                    isFaqTitleVisible 
                      ? 'opacity-100 transform translate-y-0' 
                      : 'opacity-0 transform translate-y-8'
                  }`}
                >
                  Find answers to common questions about our luxury fragrances
                </p>
              </div>

              <div 
                className={`space-y-1 transition-all duration-1000 delay-600 ${
                  isFaqContentVisible 
                    ? 'opacity-100 transform translate-y-0' 
                    : 'opacity-0 transform translate-y-12'
                }`}
              >
                <FAQItem 
                  question="How long do your perfumes last?"
                  answer="Our luxury perfumes are designed to last 6-8 hours on the skin, with some of our premium collections lasting up to 12 hours. The longevity depends on your skin type, the fragrance concentration, and environmental factors."
                />
                <FAQItem 
                  question="Do you offer fragrance consultations?"
                  answer="Yes! Visit any of our Abu Dhabi locations for a personalized fragrance consultation. Our expert perfumers will help you discover scents that complement your personality and preferences."
                />
                <FAQItem 
                  question="What's the difference between perfumes, incenses, and air fresheners?"
                  answer="Perfumes are personal fragrances worn on the body, incenses are concentrated aromatherapy products for meditation and wellness, while air fresheners are designed to scent and transform your living spaces."
                />
                <FAQItem 
                  question="Do you ship internationally?"
                  answer="Currently, we offer shipping within the UAE. For international orders, please contact our customer service team who can arrange special shipping for select products."
                />
                <FAQItem 
                  question="Can I return or exchange a fragrance?"
                  answer="We offer a 30-day return policy for unopened products. For opened fragrances, we provide exchanges within 14 days if you're not completely satisfied with your purchase."
                />
                <FAQItem 
                  question="Are your products cruelty-free?"
                  answer="Absolutely. All Grasse products are cruelty-free and we never test on animals. We're committed to ethical practices and sustainable sourcing of all our ingredients."
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Locations Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div 
            ref={locationsRef}
            className={`text-center transition-all duration-1000 ${
              isLocationsVisible 
                ? 'opacity-100 transform translate-y-0' 
                : 'opacity-0 transform translate-y-8'
            }`}
          >
            <h2 className="text-4xl font-bold text-gold-600 mb-12">
              Our Locations
            </h2>
            <div className="max-w-2xl mx-auto space-y-6">
              <div 
                ref={location1Ref}
                className={`transition-all duration-1000 ease-out delay-200 ${
                  isLocation1Visible 
                    ? 'opacity-100 transform translate-x-0' 
                    : 'opacity-0 transform -translate-x-12'
                }`}
              >
                <a 
                  href="https://maps.app.goo.gl/83sf9KMDKuGzgDFH9" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xl text-gray-700 font-medium hover:text-gold-600 transition-colors cursor-pointer"
                >
                  Dalma Mall, Abu Dhabi
                </a>
              </div>
              <div 
                ref={location2Ref}
                className={`transition-all duration-1000 ease-out delay-300 ${
                  isLocation2Visible 
                    ? 'opacity-100 transform translate-x-0' 
                    : 'opacity-0 transform translate-x-12'
                }`}
              >
                <a 
                  href="https://maps.app.goo.gl/83sf9KMDKuGzgDFH9" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xl text-gray-700 font-medium hover:text-gold-600 transition-colors cursor-pointer"
                >
                  Galeria Mall, Abu Dhabi
                </a>
              </div>
              <div 
                ref={location3Ref}
                className={`transition-all duration-1000 ease-out delay-400 ${
                  isLocation3Visible 
                    ? 'opacity-100 transform translate-x-0' 
                    : 'opacity-0 transform -translate-x-12'
                }`}
              >
                <a 
                  href="https://maps.app.goo.gl/83sf9KMDKuGzgDFH9" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xl text-gray-700 font-medium hover:text-gold-600 transition-colors cursor-pointer"
                >
                  Marina Mall, Abu Dhabi
                </a>
              </div>
              <div 
                ref={location4Ref}
                className={`transition-all duration-1000 ease-out delay-500 ${
                  isLocation4Visible 
                    ? 'opacity-100 transform translate-x-0' 
                    : 'opacity-0 transform translate-x-12'
                }`}
              >
                <a 
                  href="https://maps.app.goo.gl/83sf9KMDKuGzgDFH9" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xl text-gray-700 font-medium hover:text-gold-600 transition-colors cursor-pointer"
                >
                  Bawadi Mall, Abu Dhabi
                </a>
              </div>
              <div 
                ref={location5Ref}
                className={`transition-all duration-1000 ease-out delay-600 ${
                  isLocation5Visible 
                    ? 'opacity-100 transform translate-x-0' 
                    : 'opacity-0 transform -translate-x-12'
                }`}
              >
                <a 
                  href="https://maps.app.goo.gl/83sf9KMDKuGzgDFH9" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xl text-gray-700 font-medium hover:text-gold-600 transition-colors cursor-pointer"
                >
                  Bawabat Al Sharq Mall, Abu Dhabi
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;