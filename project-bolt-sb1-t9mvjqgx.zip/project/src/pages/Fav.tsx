import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, ShoppingBag } from 'lucide-react';
import ProductCard, { Product } from '../components/ProductCard';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

interface FavProps {
  favoriteItems: Product[];
  onAddToCart: (product: Product) => void;
  onToggleFavorite: (product: Product) => void;
  isFavorite: (productId: number) => boolean;
}

const Fav: React.FC<FavProps> = ({ favoriteItems, onAddToCart, onToggleFavorite, isFavorite }) => {
  const navigate = useNavigate();
  const [heroRef, isHeroVisible] = useScrollAnimation(0.1);
  const [gridRef, isGridVisible] = useScrollAnimation(0.05);

  return (
    <>
      {/* Hero Section */}
      <section className="relative text-white overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Favorite luxury fragrances collection"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div 
            ref={heroRef}
            className={`text-center transition-all duration-1000 ${
              isHeroVisible 
                ? 'opacity-100 transform translate-y-0' 
                : 'opacity-0 transform translate-y-8'
            }`}
          >
            <div className="flex items-center justify-center mb-6">
              <Heart className="h-12 w-12 text-red-500 fill-red-500 mr-4" />
              <h1 className="text-4xl md:text-6xl font-bold">
                <span className="text-white">Your</span>
                <span className="bg-gradient-to-r from-gold-600 to-gold-700 bg-clip-text text-transparent">
                  Favorites
                </span>
              </h1>
            </div>
            <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
              {favoriteItems.length > 0 
                ? `Discover your ${favoriteItems.length} favorite ${favoriteItems.length === 1 ? 'fragrance' : 'fragrances'} - the scents that captured your heart.`
                : "Start building your collection of favorite fragrances by clicking the heart icon on any product."
              }
            </p>
          </div>
        </div>
      </section>

      {/* Favorites Content */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {favoriteItems.length === 0 ? (
            <div className="text-center py-20">
              <div className="mb-8">
                <Heart className="h-24 w-24 text-gray-300 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-gray-600 mb-4">No favorites yet</h3>
                <p className="text-gray-500 text-lg max-w-md mx-auto">
                  Browse our collections and click the heart icon on products you love to add them here.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => {
                    navigate('/');
                    setTimeout(() => {
                      const perfumesSection = document.getElementById('perfumes');
                      if (perfumesSection) {
                        perfumesSection.scrollIntoView({ behavior: 'smooth' });
                      }
                    }, 100);
                  }}
                  className="bg-gradient-to-r from-gold-600 to-gold-700 text-white px-8 py-3 rounded-full font-semibold hover:from-gold-700 hover:to-gold-800 transition-all transform hover:scale-105 shadow-lg"
                >
                  Keep Shopping
                </button>
                <button
                  onClick={() => {
                    navigate('/about-us');
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 100);
                  }}
                  className="border-2 border-gold-600 text-gold-600 px-8 py-3 rounded-full font-semibold hover:bg-gold-600 hover:text-white transition-all"
                >
                  Learn More
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="text-center mb-16">
                <h2 className="text-4xl font-bold text-gold-600 mb-4">
                  Your Favorite Collection
                </h2>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                  {favoriteItems.length} carefully selected {favoriteItems.length === 1 ? 'fragrance' : 'fragrances'} that speak to your unique taste and style.
                </p>
              </div>

              <div 
                ref={gridRef}
                className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 transition-all duration-1000 delay-300 ${
                  isGridVisible 
                    ? 'opacity-100 transform translate-y-0' 
                    : 'opacity-0 transform translate-y-12'
                }`}
              >
                {favoriteItems.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={onAddToCart}
                    onToggleFavorite={onToggleFavorite}
                    isFavorite={isFavorite}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </section>
    </>
  );
};

export default Fav;