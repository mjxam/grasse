import React from 'react';
import { Award, Lightbulb, ShieldCheck, TrendingUp, Instagram, MapPin, Building2 } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const AboutUs: React.FC = () => {
  const [heroRef, isHeroVisible] = useScrollAnimation(0.1);
  const [originRef, isOriginVisible] = useScrollAnimation(0.1);
  const [originTextRef, isOriginTextVisible] = useScrollAnimation(0.2);
  const [originImageRef, isOriginImageVisible] = useScrollAnimation(0.2);
  const [originTitleRef, isOriginTitleVisible] = useScrollAnimation(0.1);
  const [storyRef, isStoryVisible] = useScrollAnimation(0.1);
  const [inspirationRef, isInspirationVisible] = useScrollAnimation(0.1);
  const [inspirationTextRef, isInspirationTextVisible] = useScrollAnimation(0.2);
  const [inspirationImageRef, isInspirationImageVisible] = useScrollAnimation(0.2);
  const [inspirationTitleRef, isInspirationTitleVisible] = useScrollAnimation(0.1);
  const [visionMissionRef, isVisionMissionVisible] = useScrollAnimation(0.1);
  const [visionMissionTextRef, isVisionMissionTextVisible] = useScrollAnimation(0.2);
  const [visionMissionImageRef, isVisionMissionImageVisible] = useScrollAnimation(0.2);
  const [visionMissionTitleRef, isVisionMissionTitleVisible] = useScrollAnimation(0.1);
  const [visionCardRef, isVisionCardVisible] = useScrollAnimation(0.3);
  const [missionCardRef, isMissionCardVisible] = useScrollAnimation(0.3);
  const [valuesRef, areValuesVisible] = useScrollAnimation(0.1);
  const [presenceRef, isPresenceVisible] = useScrollAnimation(0.1);

  return (
    <>
      {/* Hero Section */}
      <section className="relative text-white overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Master perfumer crafting luxury fragrances"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div 
            ref={heroRef}
            className={`text-center transition-all duration-1000 ${
              isHeroVisible 
                ? 'opacity-100 transform translate-y-0' 
                : 'opacity-0 transform translate-y-8'
            }`}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-gold-600 to-gold-700 bg-clip-text text-transparent overflow-visible">
                About Grasse
              </span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
              An Emirati perfume company inspired by Grasse, France—the global capital of luxury perfumery.
              Since 2019, we've crafted exceptional Arabic and French fragrances using original oils and raw materials,
              achieving remarkable success in the UAE and expanding to international markets including Russia.
            </p>
          </div>
        </div>
      </section>

      {/* Our Origin Section */}
      <section className="py-20 bg-#ffffff">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            ref={originRef}
            className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
          >
            {/* Story Content - Left Side */}
            <div
              ref={originTextRef}
              className={`space-y-6 transition-all duration-1000 ease-out ${
                isOriginTextVisible
                  ? 'opacity-100 transform translate-x-0'
                  : 'opacity-0 transform -translate-x-12'
              }`}
            >
              <div
                ref={originTitleRef}
                className={`inline-block transition-all duration-800 ${
                  isOriginTitleVisible
                    ? 'opacity-100 transform translate-y-0'
                    : 'opacity-0 transform translate-y-4'
                }`}
              >
                <span className="text-sm font-semibold text-gold-600 uppercase tracking-wider bg-gold-50 px-3 py-1 rounded-full border border-gold-200">
                  Our Origin
                </span>
              </div>

              <h2
                className={`text-4xl md:text-5xl font-bold leading-tight transition-all duration-1000 delay-200 ${
                  isOriginTitleVisible
                    ? 'opacity-100 transform translate-y-0'
                    : 'opacity-0 transform translate-y-6'
                }`}
              >
                <span className="text-gray-900 overflow-visible">Our Journey of</span>
                <span className="block bg-gradient-to-r from-gold-600 to-gold-700 bg-clip-text text-transparent overflow-visible">
                  Excellence
                </span>
              </h2>

              <div
                className={`space-y-4 text-gray-600 text-lg leading-relaxed transition-all duration-1000 delay-400 ${
                  isOriginTextVisible
                    ? 'opacity-100 transform translate-y-0'
                    : 'opacity-0 transform translate-y-8'
                }`}
              >
                <p>
                  It started its first steps in 2019 and achieved great success among the successful perfume brands
                  and proved its presence in the Emirati perfume market in a short time.
                </p>
              </div>
            </div>

            {/* Story Image - Right Side */}
            <div
              ref={originImageRef}
              className={`relative transition-all duration-1000 ease-out delay-200 ${
                isOriginImageVisible
                  ? 'opacity-100 transform translate-x-0'
                  : 'opacity-0 transform translate-x-12'
              }`}
            >
              <div className="relative overflow-hidden rounded-2xl shadow-2xl" style={{ height: '600px' }}>
                <img
                  src="https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Master perfumer crafting luxury perfumes"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>

                {/* Floating Elements */}
                <div className="absolute top-6 right-6 bg-white/90 backdrop-blur-sm rounded-full p-3 border border-amber-200">
                  <div className="text-gold-600 text-sm font-semibold">Est. 1985</div>
                </div>

                <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur-sm rounded-xl p-4 border border-amber-200 max-w-xs">
                  <div className="text-white text-sm font-medium mb-1">Marie Dubois</div>
                  <div className="text-gold-600 text-xs">Founder & Master Perfumer</div>
                </div>
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-br from-gold-200/40 to-gold-300/40 rounded-full blur-xl"></div>
              <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-gradient-to-br from-gold-300/40 to-gold-200/40 rounded-full blur-xl"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Who Are We */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div 
            ref={storyRef}
            className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center transition-all duration-1000 ${
              isStoryVisible 
                ? 'opacity-100 transform translate-y-0' 
                : 'opacity-0 transform translate-y-8'
            }`}
          >
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Perfume crafting process"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent rounded-2xl"></div>
            </div>
            <div>
              <h2 className="text-4xl font-bold text-gold-600 mb-6">Who are we?</h2>
              <p className="text-gray-600 text-lg mb-6">
                We are an Emirati perfume company that offers the best and most luxurious Arabic and French perfumes, and we strive to satisfy different Arab and international tastes through the manufacture and presentation of our products, and we strive to reach international markets As we are now available in Russian federation market.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* The Inspiration Section */}
      <section className="py-20 bg-#ffffff">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            ref={inspirationRef}
            className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
          >
            {/* Text Content - Left Side */}
            <div
              ref={inspirationTextRef}
              className={`space-y-6 transition-all duration-1000 ease-out ${
                isInspirationTextVisible
                  ? 'opacity-100 transform translate-x-0'
                  : 'opacity-0 transform -translate-x-12'
              }`}
            >
              <div
                ref={inspirationTitleRef}
                className={`inline-block transition-all duration-800 ${
                  isInspirationTitleVisible
                    ? 'opacity-100 transform translate-y-0'
                    : 'opacity-0 transform translate-y-4'
                }`}
              >
                <span className="text-sm font-semibold text-gold-600 uppercase tracking-wider bg-gold-50 px-3 py-1 rounded-full border border-gold-200">
                  Our Inspiration
                </span>
              </div>

              <h2
                className={`text-4xl md:text-5xl font-bold leading-tight transition-all duration-1000 delay-200 ${
                  isInspirationTitleVisible
                    ? 'opacity-100 transform translate-y-0'
                    : 'opacity-0 transform translate-y-6'
                }`}
              >
                <span className="text-gray-900 overflow-visible">The</span>
                <span className="block bg-gradient-to-r from-gold-600 to-gold-700 bg-clip-text text-transparent overflow-visible">
                  Inspiration
                </span>
              </h2>

              <div
                className={`space-y-4 text-gray-600 text-lg leading-relaxed transition-all duration-1000 delay-400 ${
                  isInspirationTextVisible
                    ? 'opacity-100 transform translate-y-0'
                    : 'opacity-0 transform translate-y-8'
                }`}
              >
                <p>
                  Grasse name for a French city Grasse is considered the global capital for the manufacture of the most luxurious perfumes and has become famous in the contemporary cultural imagination as the pioneer of international perfumes, and from here the Grasse Perfumes Company began to manufacture and provide the best and finest international perfumes using original oils and raw materials.
                </p>
              </div>
            </div>

            {/* Image - Right Side */}
            <div
              ref={inspirationImageRef}
              className={`relative transition-all duration-1000 ease-out delay-200 ${
                isInspirationImageVisible
                  ? 'opacity-100 transform translate-x-0'
                  : 'opacity-0 transform translate-x-12'
              }`}
            >
              <div className="relative overflow-hidden rounded-2xl shadow-2xl" style={{ height: '600px' }}>
                <img
                  src="https://images.pexels.com/photos/1961795/pexels-photo-1961795.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="French perfumery heritage and craftsmanship"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>

                {/* Floating Elements */}
                <div className="absolute top-6 right-6 bg-white/90 backdrop-blur-sm rounded-full p-3 border border-amber-200">
                  <div className="text-gold-600 text-sm font-semibold">Grasse, France</div>
                </div>

                <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur-sm rounded-xl p-4 border border-amber-200 max-w-xs">
                  <div className="text-gray-900 text-sm font-medium mb-1">Perfume Capital</div>
                  <div className="text-gold-600 text-xs">Heritage • Quality • Excellence</div>
                </div>
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-br from-gold-200/40 to-gold-300/40 rounded-full blur-xl"></div>
              <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-gradient-to-br from-gold-300/40 to-gold-200/40 rounded-full blur-xl"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Vision and Mission Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header and Image */}
          <div className="text-center mb-16">
            <div
              ref={visionMissionTitleRef}
              className={`mb-6 transition-all duration-800 inline-block ${
                isVisionMissionTitleVisible
                  ? 'opacity-100 transform translate-y-0'
                  : 'opacity-0 transform translate-y-4'
              }`}
            >
              <span className="text-sm font-semibold text-gold-600 uppercase tracking-wider bg-gold-50 px-3 py-1 rounded-full border border-gold-200">
                Our Purpose
              </span>
            </div>

            <h2
              className={`text-4xl md:text-5xl font-bold leading-tight mb-12 transition-all duration-1000 delay-200 ${
                isVisionMissionTitleVisible
                  ? 'opacity-100 transform translate-y-0'
                  : 'opacity-0 transform translate-y-6'
              }`}
            >
              <span className="text-gray-900 overflow-visible">Vision & </span>
              <span className="bg-gradient-to-r from-gold-600 to-gold-700 bg-clip-text text-transparent overflow-visible">
                Mission
              </span>
            </h2>

            {/* Image */}
            <div
              ref={visionMissionImageRef}
              className={`relative max-w-4xl mx-auto transition-all duration-1000 ease-out ${
                isVisionMissionImageVisible
                  ? 'opacity-100 transform translate-y-0'
                  : 'opacity-0 transform translate-y-8'
              }`}
            >
              <div className="relative overflow-hidden rounded-2xl shadow-2xl" style={{ height: '400px' }}>
                <img
                  src="https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Arabic luxury perfumes and traditional craftsmanship"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>

                {/* Floating Elements */}
                <div className="absolute top-6 right-6 bg-white/90 backdrop-blur-sm rounded-full p-3 border border-amber-200">
                  <div className="text-gold-600 text-sm font-semibold">Arabic Heritage</div>
                </div>

                <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur-sm rounded-xl p-4 border border-amber-200 max-w-xs">
                  <div className="text-gray-900 text-sm font-medium mb-1">Authentic Luxury</div>
                  <div className="text-gold-600 text-xs">Traditional • Modern • Excellence</div>
                </div>
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-gradient-to-br from-gold-200/40 to-gold-300/40 rounded-full blur-xl"></div>
              <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-br from-gold-300/40 to-gold-200/40 rounded-full blur-xl"></div>
            </div>
          </div>

          {/* Vision and Mission Cards - Side by Side */}
          <div
            ref={visionMissionRef}
            className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto"
          >
            {/* Vision Statement */}
            <div
              ref={visionCardRef}
              className={`bg-gray-50 rounded-xl p-8 border border-gray-200 shadow-sm transition-all duration-1000 delay-400 ${
                isVisionCardVisible
                  ? 'opacity-100 transform translate-y-0'
                  : 'opacity-0 transform translate-y-8'
              }`}
            >
              <h3 className="text-xl font-bold text-gold-600 mb-4 flex items-center">
                <div className="w-8 h-8 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white text-sm font-bold">V</span>
                </div>
                Vision Statement
              </h3>
              <p className="text-gray-700 leading-relaxed">
                To be the leading company in the manufacture of Arabic and French perfumes globally.
              </p>
            </div>

            {/* Mission Statement */}
            <div
              ref={missionCardRef}
              className={`bg-gray-50 rounded-xl p-8 border border-gray-200 shadow-sm transition-all duration-1000 delay-600 ${
                isMissionCardVisible
                  ? 'opacity-100 transform translate-y-0'
                  : 'opacity-0 transform translate-y-8'
              }`}
            >
              <h3 className="text-xl font-bold text-gold-600 mb-4 flex items-center">
                <div className="w-8 h-8 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white text-sm font-bold">M</span>
                </div>
                The Mission
              </h3>
              <p className="text-gray-700 leading-relaxed">
                To be the world-leading company in the field of manufacturing and providing Arabic and French perfumes with high quality products, in terms of original crude oils as well as the best talents in the industry.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div 
            ref={valuesRef}
            className={`text-center mb-16 transition-all duration-1000 ${
              areValuesVisible 
                ? 'opacity-100 transform translate-y-0' 
                : 'opacity-0 transform translate-y-8'
            }`}
          >
            <h2 className="text-4xl font-bold text-gold-600 mb-4">Our Values</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Quality - Credibility - Excellence and creativity - Trust
            </p>
          </div>

          <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 transition-all duration-1000 delay-300 ${
            areValuesVisible 
              ? 'opacity-100 transform translate-y-0' 
              : 'opacity-0 transform translate-y-12'
          }`}>
            <div className="text-center p-6 bg-white rounded-2xl border border-gray-200 hover:border-amber-600/50 transition-all shadow-sm">
              <div className="w-16 h-16 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Quality</h3>
              <p className="text-gray-600">
                We never compromise on quality, using only the finest ingredients and time-tested techniques.
              </p>
            </div>

            <div className="text-center p-6 bg-white rounded-2xl border border-gray-200 hover:border-amber-600/50 transition-all shadow-sm">
              <div className="w-16 h-16 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShieldCheck className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Credibility</h3>
              <p className="text-gray-600">
                Building trust through transparency and authentic relationships with our customers.
              </p>
            </div>

            <div className="text-center p-6 bg-white rounded-2xl border border-gray-200 hover:border-amber-600/50 transition-all shadow-sm">
              <div className="w-16 h-16 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lightbulb className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Excellence and Creativity</h3>
              <p className="text-gray-600">
                Combining traditional craftsmanship with innovative artistry to create unique fragrances.
              </p>
            </div>

            <div className="text-center p-6 bg-white rounded-2xl border border-gray-200 hover:border-amber-600/50 transition-all shadow-sm">
              <div className="w-16 h-16 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Trust</h3>
              <p className="text-gray-600">
                Delivering on our promises and maintaining the highest standards in every product.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Presence */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            ref={presenceRef}
            className={`text-center mb-16 transition-all duration-1000 ${
              isPresenceVisible
                ? 'opacity-100 transform translate-y-0'
                : 'opacity-0 transform translate-y-8'
            }`}
          >
            <h2 className="text-4xl font-bold text-gold-600 mb-4">Our Presence</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Connecting with our customers across multiple channels and locations
            </p>
          </div>

          <div className={`grid grid-cols-1 md:grid-cols-3 gap-8 transition-all duration-1000 delay-300 ${
            isPresenceVisible
              ? 'opacity-100 transform translate-y-0'
              : 'opacity-0 transform translate-y-12'
          }`}>
            <div className="text-center p-6 bg-gray-50 rounded-2xl border border-gray-200 hover:border-amber-600/50 transition-all shadow-sm">
              <div className="w-16 h-16 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Instagram className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Social Media</h3>
              <p className="text-gray-600">
                Snapchat and Instagram account are among the first steps we have taken to communicate with our customers since 2019
              </p>
            </div>

            <div className="text-center p-6 bg-gray-50 rounded-2xl border border-gray-200 hover:border-amber-600/50 transition-all shadow-sm">
              <div className="w-16 h-16 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Retail Branches</h3>
              <p className="text-gray-600">
                We Have our branches in the global shopping centers in the United Arab Emirates, and we strive to be present in all international shopping centers in the Gulf.
              </p>
            </div>

            <div className="text-center p-6 bg-gray-50 rounded-2xl border border-gray-200 hover:border-amber-600/50 transition-all shadow-sm">
              <div className="w-16 h-16 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Building2 className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Headquarters</h3>
              <p className="text-gray-600">
                The Company's headquarters in the United Arab Emirates, in the Emirate of Dubai, in Business Bay area, with future expansion plans in the Gulf region and international markets.
              </p>
            </div>
          </div>
        </div>
      </section>

    </>
  );
};

export default AboutUs;