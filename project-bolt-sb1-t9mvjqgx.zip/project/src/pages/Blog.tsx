import React, { useState } from 'react';
import { Search, Filter } from 'lucide-react';
import BlogCard from '../components/BlogCard';
import { blogPosts, BlogPost } from '../data/blogs';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const Blog: React.FC = () => {
  const [heroRef, isHeroVisible] = useScrollAnimation(0.1);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedBlog, setSelectedBlog] = useState<BlogPost | null>(null);

  const categories = ['All', ...Array.from(new Set(blogPosts.map(post => post.category)))];

  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'All' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleReadMore = (blog: BlogPost) => {
    setSelectedBlog(blog);
  };

  const handleCloseBlog = () => {
    setSelectedBlog(null);
  };

  if (selectedBlog) {
    return (
      <div className="min-h-screen bg-gray-900 text-white relative overflow-hidden">
        {/* Subtle Mountain Background */}
        <div className="absolute inset-0 opacity-20">
          <svg
            className="absolute bottom-0 w-full h-full"
            viewBox="0 0 1200 600"
            preserveAspectRatio="xMidYEnd slice"
            fill="none"
          >
            {/* Far mountains - barely visible */}
            <path
              d="M0 400 L200 250 L400 280 L600 220 L800 260 L1000 200 L1200 240 L1200 600 L0 600 Z"
              fill="url(#mountain-gradient-1)"
              opacity="0.4"
            />
            <path
              d="M0 450 L150 320 L350 350 L550 300 L750 340 L950 280 L1200 320 L1200 600 L0 600 Z"
              fill="url(#mountain-gradient-2)"
              opacity="0.5"
            />
            <path
              d="M0 500 L100 380 L300 420 L500 360 L700 400 L900 340 L1200 380 L1200 600 L0 600 Z"
              fill="url(#mountain-gradient-3)"
              opacity="0.6"
            />
            
            {/* Gradient definitions */}
            <defs>
              <linearGradient id="mountain-gradient-1" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#374151" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#1f2937" stopOpacity="0.1" />
              </linearGradient>
              <linearGradient id="mountain-gradient-2" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#4b5563" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#374151" stopOpacity="0.2" />
              </linearGradient>
              <linearGradient id="mountain-gradient-3" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#6b7280" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#4b5563" stopOpacity="0.3" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={handleCloseBlog}
            className="mb-8 text-gold-500 hover:text-gold-400 transition-colors"
          >
            ← Back to Blog
          </button>
          
          <article>
            <div className="mb-8">
              <img 
                src={selectedBlog.image} 
                alt={selectedBlog.title}
                className="w-full h-64 md:h-96 object-cover rounded-2xl"
              />
            </div>
            
            <div className="mb-6">
              <span className="text-sm font-semibold text-gold-500 uppercase tracking-wider bg-gold-500/10 px-3 py-1 rounded-full">
                {selectedBlog.category}
              </span>
            </div>
            
            <h1 className="text-3xl md:text-5xl font-bold text-white mb-6">
              {selectedBlog.title}
            </h1>
            
            <div className="flex items-center space-x-6 text-gray-400 mb-8">
              <span>By {selectedBlog.author}</span>
              <span>{new Date(selectedBlog.date).toLocaleDateString()}</span>
              <span>{selectedBlog.readTime}</span>
            </div>
            
            <div className="prose prose-lg prose-invert max-w-none">
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                {selectedBlog.excerpt}
              </p>
              
              <div className="text-gray-300 leading-relaxed space-y-6">
                <p>
                  {selectedBlog.content} Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                  Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad 
                  minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea 
                  commodo consequat.
                </p>
                
                <p>
                  Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore 
                  eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt 
                  in culpa qui officia deserunt mollit anim id est laborum.
                </p>
                
                <p>
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                  doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore 
                  veritatis et quasi architecto beatae vitae dicta sunt explicabo.
                </p>
              </div>
            </div>
            
            <div className="mt-8 pt-8 border-t border-gray-700">
              <div className="flex flex-wrap gap-2">
                {selectedBlog.tags.map((tag) => (
                  <span 
                    key={tag}
                    className="text-sm text-gray-400 bg-gray-700 px-3 py-1 rounded-full"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          </article>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Hero Section */}
      <section className="relative text-white overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Luxury fragrance collection and products"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div 
            ref={heroRef}
            className={`text-center transition-all duration-1000 ${
              isHeroVisible 
                ? 'opacity-100 transform translate-y-0' 
                : 'opacity-0 transform translate-y-8'
            }`}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="text-white">Fragrance</span>
              <span className="block bg-gradient-to-r from-gold-300 to-gold-400 bg-clip-text text-transparent">
                Journal
              </span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
              Discover the art, science, and stories behind luxury fragrances. From expert tips 
              to industry insights, explore the world of scent with our curated collection of articles.
            </p>
          </div>
        </div>
      </section>

      {/* Blog Content */}
      <section className="py-12 bg-#ffffff">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Search and Filter */}
          <div className="mb-8 flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-500" />
              <input
                type="text"
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-#ffffff border border-gray-300 rounded-full text-gray-900 placeholder-gray-500 focus:outline-none focus:border-gold-600 transition-colors"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5 text-gray-500" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-#ffffff border border-gray-300 rounded-full px-4 py-3 text-gray-900 focus:outline-none focus:border-gold-600 transition-colors"
              >
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Blog Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((blog) => (
              <BlogCard
                key={blog.id}
                blog={blog}
                onReadMore={handleReadMore}
              />
            ))}
          </div>

          {filteredPosts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">No articles found matching your criteria.</p>
              <p className="text-gray-500 text-sm mt-2">Try adjusting your search or filter options.</p>
            </div>
          )}
        </div>
      </section>
    </>
  );
};

export default Blog;