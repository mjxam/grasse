import React, { useState, useMemo } from 'react';
import ProductCard, { Product } from '../components/ProductCard';
import ProductFilter, { FilterOptions } from '../components/ProductFilter';
import { ouds } from '../data/products';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

interface OudsProps {
  onAddToCart: (product: Product) => void;
  onToggleFavorite: (product: Product) => void;
  isFavorite: (productId: number) => boolean;
}

const Ouds: React.FC<OudsProps> = ({ onAddToCart, onToggleFavorite, isFavorite }) => {
  const [heroRef, isHeroVisible] = useScrollAnimation(0.1);
  const [gridRef, isGridVisible] = useScrollAnimation(0.1);
  const [filters, setFilters] = useState<FilterOptions>({
    priceRange: [0, 200],
    gender: 'all',
    sortBy: 'name'
  });
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const filteredAndSortedProducts = useMemo(() => {
    let filtered = ouds.filter(product => {
      const withinPriceRange = product.price >= filters.priceRange[0] && product.price <= filters.priceRange[1];
      const matchesGender = filters.gender === 'all' || product.gender === filters.gender;
      return withinPriceRange && matchesGender;
    });

    filtered.sort((a, b) => {
      switch (filters.sortBy) {
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        case 'rating':
          return b.rating - a.rating;
        case 'name':
        default:
          return a.name.localeCompare(b.name);
      }
    });

    return filtered;
  }, [filters]);

  return (
    <>
      <section className="relative text-white overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Luxury oud collection"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div
            ref={heroRef}
            className={`text-center transition-all duration-1000 ${
              isHeroVisible
                ? 'opacity-100 transform translate-y-0'
                : 'opacity-0 transform translate-y-8'
            }`}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="text-white">Premium</span>
              <span className="block bg-gradient-to-r from-gold-300 to-gold-400 bg-clip-text text-transparent">
                Ouds
              </span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
              Experience the essence of Arabian luxury with our authentic oud collection. Each piece is crafted
              with traditional methods and the finest ingredients to deliver an unforgettable olfactory journey.
            </p>
          </div>
        </div>
      </section>

      <section className="py-8 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {filters.priceRange[0] === 0 && filters.priceRange[1] === 200 && filters.gender === 'all' && filters.sortBy === 'name' ? (
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold text-gold-600 mb-4">
                All Ouds
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
                Discover your perfect oud from our curated collection of {filteredAndSortedProducts.length} luxury ouds
              </p>
              <div className="flex justify-start">
                <ProductFilter
                  filters={filters}
                  onFiltersChange={setFilters}
                  isOpen={isFilterOpen}
                  onToggle={() => setIsFilterOpen(!isFilterOpen)}
                  productCount={filteredAndSortedProducts.length}
                />
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">
                  Filtered Ouds ({filteredAndSortedProducts.length})
                </h2>
                <p className="text-gray-600 mt-1">
                  Results matching your selected criteria
                </p>
              </div>
              <ProductFilter
                filters={filters}
                onFiltersChange={setFilters}
                isOpen={isFilterOpen}
                onToggle={() => setIsFilterOpen(!isFilterOpen)}
                productCount={filteredAndSortedProducts.length}
              />
            </div>
          )}
        </div>
      </section>

      <div className="bg-gray-50 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            ref={gridRef}
            className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 transition-all duration-1000 ${
              isGridVisible
                ? 'opacity-100 transform translate-y-0'
                : 'opacity-0 transform translate-y-12'
            }`}
          >
            {filteredAndSortedProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={onAddToCart}
                onToggleFavorite={onToggleFavorite}
                isFavorite={isFavorite}
              />
            ))}
          </div>

          {filteredAndSortedProducts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">No ouds found matching your criteria.</p>
              <p className="text-gray-500 text-sm mt-2">Try adjusting your filters to see more products.</p>
            </div>
          )}
        </div>
      </div>

    </>
  );
};

export default Ouds;
