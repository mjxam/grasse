import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ShoppingCart, Heart, Star, Package, Truck, Shield, ArrowLeft } from 'lucide-react';
import { perfumes, incenses, airFresheners, ouds } from '../data/products';
import { Product } from '../components/ProductCard';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

interface ProductDetailProps {
  onAddToCart: (product: Product) => void;
  onToggleFavorite: (product: Product) => void;
  isFavorite: (productId: number) => boolean;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ onAddToCart, onToggleFavorite, isFavorite }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [imageRef, isImageVisible] = useScrollAnimation(0.1);
  const [detailsRef, isDetailsVisible] = useScrollAnimation(0.1);
  const [featuresRef, isFeaturesVisible] = useScrollAnimation(0.1);

  const allProducts = [...perfumes, ...incenses, ...airFresheners, ...ouds];
  const product = allProducts.find(p => p.id === parseInt(id || '0'));

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Product Not Found</h2>
          <p className="text-gray-600 mb-6">The product you're looking for doesn't exist.</p>
          <Link
            to="/"
            className="inline-block bg-gradient-to-r from-gold-600 to-gold-700 text-white px-6 py-3 rounded-full font-semibold hover:from-gold-700 hover:to-gold-800 transition-all"
          >
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  const productImages = product.images && product.images.length > 0 ? product.images : [product.image];
  const discountPercentage = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const relatedProducts = allProducts
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      onAddToCart(product);
    }
  };

  const getCategoryPath = (category: string) => {
    const categoryMap: { [key: string]: string } = {
      'Perfume': '/perfumes',
      'Incense': '/incenses',
      'Air Freshener': '/air-fresheners',
      'Oud': '/ouds'
    };
    return categoryMap[category] || '/';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-gray-600 hover:text-gold-600 mb-8 transition-colors"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div
            ref={imageRef}
            className={`flex flex-col transition-all duration-1000 ${
              isImageVisible ? 'opacity-100 transform translate-x-0' : 'opacity-0 transform -translate-x-12'
            }`}
          >
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-4 flex-grow-0">
              <div className="relative aspect-square">
                <img
                  src={productImages[selectedImage]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                {discountPercentage > 0 && (
                  <div className="absolute top-6 left-6 bg-red-500 text-white px-4 py-2 rounded-full text-sm font-semibold">
                    -{discountPercentage}% OFF
                  </div>
                )}
              </div>
            </div>

            {productImages.length > 1 && (
              <div className="grid grid-cols-4 gap-4 flex-grow-0">
                {productImages.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`bg-white rounded-xl overflow-hidden border-2 transition-all ${
                      selectedImage === index ? 'border-gold-600' : 'border-gray-200 hover:border-gold-400'
                    }`}
                  >
                    <img src={image} alt={`${product.name} ${index + 1}`} className="w-full h-full object-cover aspect-square" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div
            ref={detailsRef}
            className={`flex flex-col transition-all duration-1000 delay-200 ${
              isDetailsVisible ? 'opacity-100 transform translate-x-0' : 'opacity-0 transform translate-x-12'
            }`}
          >
            <div className="bg-white rounded-2xl shadow-lg p-8 h-full flex flex-col">
              <div className="mb-4">
                <Link
                  to={getCategoryPath(product.category)}
                  className="text-sm font-semibold text-gold-600 uppercase tracking-wider bg-gold-50 px-3 py-1 rounded-full border border-gold-200 inline-block hover:bg-gold-100 transition-colors"
                >
                  {product.category}
                </Link>
              </div>

              <h1 className="text-4xl font-bold text-gray-900 mb-4">{product.name}</h1>

              <div className="flex items-center mb-6">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(product.rating) ? 'text-gold-500 fill-gold-500' : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="ml-2 text-lg text-gray-600">
                  {product.rating} <span className="text-sm">(128 reviews)</span>
                </span>
              </div>

              <div className="flex items-baseline space-x-4 mb-6">
                <span className="text-5xl font-bold text-gray-900">{product.price} AED</span>
                {product.originalPrice && (
                  <span className="text-2xl text-gray-400 line-through">{product.originalPrice} AED</span>
                )}
              </div>

              <p className="text-gray-700 text-lg leading-relaxed mb-8">{product.description}</p>

              {product.gender && (
                <div className="mb-6">
                  <span className="text-sm text-gray-600 font-medium">For:</span>
                  <span className="ml-2 text-gray-900 capitalize font-semibold">{product.gender}</span>
                </div>
              )}

              <div className="flex items-center space-x-4 mb-8">
                <div className="flex items-center border-2 border-gray-300 rounded-full">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-6 py-3 text-gray-600 hover:text-gray-900 font-bold"
                  >
                    -
                  </button>
                  <span className="px-6 py-3 font-bold text-gray-900">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-6 py-3 text-gray-600 hover:text-gray-900 font-bold"
                  >
                    +
                  </button>
                </div>

                <button
                  onClick={handleAddToCart}
                  className="flex-1 bg-gradient-to-r from-gold-600 to-gold-700 text-white px-6 py-3 rounded-full hover:from-gold-700 hover:to-gold-800 transition-all flex items-center justify-center space-x-2 transform hover:scale-105 shadow-lg hover:shadow-gold-600/25 font-semibold"
                >
                  <ShoppingCart className="h-5 w-5" />
                  <span>Add to Cart</span>
                </button>

                <button
                  onClick={() => onToggleFavorite(product)}
                  className={`p-3 rounded-full transition-all shadow-md ${
                    isFavorite(product.id)
                      ? 'bg-red-50 text-red-500'
                      : 'bg-white text-gray-400 hover:bg-red-50 hover:text-red-500'
                  }`}
                >
                  <Heart
                    className={`h-5 w-5 ${isFavorite(product.id) ? 'fill-red-500' : ''}`}
                  />
                </button>
              </div>

              <div className="border-t border-gray-200 pt-6">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <Package className="h-8 w-8 text-gold-600 mx-auto mb-2" />
                    <p className="text-sm font-semibold text-gray-900">Premium Quality</p>
                    <p className="text-xs text-gray-600">Luxury Materials</p>
                  </div>
                  <div>
                    <Truck className="h-8 w-8 text-gold-600 mx-auto mb-2" />
                    <p className="text-sm font-semibold text-gray-900">Free Shipping</p>
                    <p className="text-xs text-gray-600">On orders $50+</p>
                  </div>
                  <div>
                    <Shield className="h-8 w-8 text-gold-600 mx-auto mb-2" />
                    <p className="text-sm font-semibold text-gray-900">Secure Payment</p>
                    <p className="text-xs text-gray-600">100% Protected</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div
          ref={featuresRef}
          className={`bg-white rounded-2xl shadow-lg p-8 mb-16 transition-all duration-1000 ${
            isFeaturesVisible ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-12'
          }`}
        >
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Product Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-semibold text-gold-600 mb-4">Description</h3>
              <p className="text-gray-700 leading-relaxed">
                {product.description} This exquisite fragrance is crafted with precision and care,
                using only the finest ingredients sourced from around the world. Each note has been
                carefully selected to create a harmonious and unforgettable scent experience.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gold-600 mb-4">Features</h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-gold-600 rounded-full mr-3"></span>
                  Long-lasting fragrance (6-8 hours)
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-gold-600 rounded-full mr-3"></span>
                  Premium quality ingredients
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-gold-600 rounded-full mr-3"></span>
                  Elegant packaging
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-gold-600 rounded-full mr-3"></span>
                  Suitable for all occasions
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-gold-600 rounded-full mr-3"></span>
                  Cruelty-free and ethically sourced
                </li>
              </ul>
            </div>
          </div>
        </div>

        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-8">You May Also Like</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((relatedProduct) => (
                <Link
                  key={relatedProduct.id}
                  to={`/product/${relatedProduct.id}`}
                  className="group bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-500 transform hover:-translate-y-2 overflow-hidden border border-gray-200"
                >
                  <div className="aspect-square overflow-hidden bg-gradient-to-br from-gray-100 to-amber-50">
                    <img
                      src={relatedProduct.image}
                      alt={relatedProduct.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-gray-900 mb-2 group-hover:text-gold-600 transition-colors">
                      {relatedProduct.name}
                    </h3>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">{relatedProduct.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xl text-gray-900">{relatedProduct.price} AED</span>
                      <span className="text-xs font-semibold text-gold-600 uppercase tracking-wider bg-gold-50 px-2 py-1 rounded-full">
                        {relatedProduct.category}
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;
