import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import StarField from './StarField';

const AnimatedText: React.FC<{ text: string; delay?: number; className?: string }> = ({ 
  text, 
  delay = 0, 
  className = "" 
}) => {
  const [visibleChars, setVisibleChars] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      const interval = setInterval(() => {
        setVisibleChars(prev => {
          if (prev >= text.length) {
            clearInterval(interval);
            return prev;
          }
          return prev + 1;
        });
      }, 15); // 15ms between each character for much faster typing

      return () => clearInterval(interval);
    }, delay);

    return () => clearTimeout(timer);
  }, [text, delay]);

  return (
    <span className={className}>
      {text.split('').map((char, index) => (
        <span
          key={index}
          className={`inline-block transition-all duration-300 ${
            index < visibleChars 
              ? 'opacity-100 transform translate-y-0' 
              : 'opacity-0 transform translate-y-4'
          }`}
          style={{
            transitionDelay: `${index * 15}ms`
          }}
        >
          {char === ' ' ? '\u00A0' : char}
        </span>
      ))}
    </span>
  );
};

const Hero: React.FC = () => {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToPerfumes = () => {
    const perfumesSection = document.getElementById('perfumes');
    if (perfumesSection) {
      perfumesSection.scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
      });
    }
  };

  return (
    <section id="home" className="relative text-white overflow-hidden min-h-screen flex items-center">
      {/* Background Image */}
      <div
        className="absolute inset-0 w-full h-full"
        style={{
          transform: `translateY(${scrollY * 0.5}px)`,
          willChange: 'transform'
        }}
      >
        <img
          src="/Home Banner copy.jpg"
          alt="Luxury perfume background"
          className="w-full h-full object-cover object-center"
          style={{
            minHeight: '100vh',
            minWidth: '100vw'
          }}
        />
        <div
          className="absolute inset-0 bg-black/50"
          style={{
            opacity: Math.min(0.5 + scrollY * 0.001, 0.8)
          }}
        ></div>
      </div>

      <div
        className="relative w-full mx-auto px-4 sm:px-6 lg:px-8 py-24 z-10"
        style={{
          transform: `translateY(${scrollY * -0.2}px)`,
          willChange: 'transform'
        }}
      >
        <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
              <AnimatedText text="Discover Your" className="text-white" />
              <span className="block text-gold-300">
                <AnimatedText text="Signature Scent" delay={200} />
              </span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
              <AnimatedText 
                text="Luxury perfumes, premium essences, and sophisticated air fresheners crafted to elevate every moment of your day." 
                delay={400}
              />
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center opacity-0 animate-fade-in-final">
            <button 
              onClick={scrollToPerfumes}
              className="bg-gradient-to-r from-gold-400 to-gold-500 text-gray-900 px-8 py-3 rounded-full font-semibold hover:from-gold-300 hover:to-gold-400 transition-all transform hover:scale-105 shadow-lg"
            >
                Shop Collection
              </button>
              <Link 
                to="/about-us"
               onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className="border-2 border-gold-400 text-gold-400 px-8 py-3 rounded-full font-semibold hover:bg-gold-400 hover:text-gray-900 transition-all shadow-lg text-center"
              >
                Learn More
              </Link>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;