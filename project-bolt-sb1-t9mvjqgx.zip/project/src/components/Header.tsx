import React from 'react';
import { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ShoppingCart, Search, Menu, X } from 'lucide-react';

interface HeaderProps {
  cartItemsCount: number;
  onCartClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ cartItemsCount, onCartClick }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const scrollTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const isActive = (path: string) => {
    if (path === '/' && location.pathname === '/') return true;
    if (path !== '/' && location.pathname.startsWith(path)) return true;
    return false;
  };

  const searchData = [
    { title: 'Home', path: '/', type: 'page' },
    { title: 'Perfumes', path: '/perfumes', type: 'page' },
    { title: 'Incenses', path: '/incenses', type: 'page' },
    { title: 'Air Fresheners', path: '/air-fresheners', type: 'page' },
    { title: 'Ouds', path: '/ouds', type: 'page' },
    { title: 'About Us', path: '/about-us', type: 'page' },
    { title: 'Contact Us', path: '/contact-us', type: 'page' },
    { title: 'Favorites', path: '/fav', type: 'page' },
    // Perfumes
    { title: 'Cannes', path: '/product/1', type: 'product' },
    { title: 'Lorient', path: '/product/2', type: 'product' },
    { title: 'No Way', path: '/product/3', type: 'product' },
    { title: 'Real Summer', path: '/product/4', type: 'product' },
    { title: 'Season', path: '/product/5', type: 'product' },
    { title: 'Storm', path: '/product/6', type: 'product' },
    { title: 'Touch Of Me', path: '/product/7', type: 'product' },
    { title: 'كشخة', path: '/product/8', type: 'product' },
    // Incenses
    { title: 'Dokhon Abudhabi', path: '/product/101', type: 'product' },
    { title: 'Dokhon Alain', path: '/product/102', type: 'product' },
    // Air Fresheners
    { title: 'No Way Air Freshener', path: '/product/201', type: 'product' },
    { title: 'Season Air Freshener', path: '/product/202', type: 'product' },
    { title: 'Touch Of Me Air Freshener', path: '/product/203', type: 'product' },
  ];

  const filteredResults = searchQuery.trim() 
    ? searchData.filter(item => 
        item.title.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 8)
    : [];

  const handleSearchClick = (path: string) => {
    setIsSearchOpen(false);
    setSearchQuery('');
    if (path === location.pathname) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      navigate(path);
      setTimeout(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 100);
    }
  };

  const handleSearchToggle = () => {
    setIsSearchOpen(!isSearchOpen);
    if (!isSearchOpen) {
      setSearchQuery('');
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (filteredResults.length > 0) {
      handleSearchClick(filteredResults[0].path);
    }
  };

  // Close search when clicking outside
  React.useEffect(() => {
    const handleClickOutside = () => setIsSearchOpen(false);
    if (isSearchOpen) document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [isSearchOpen]);

  const handleNavClick = (path: string, e: React.MouseEvent) => {
    // Always scroll to top when navigating
    window.scrollTo({ 
      top: 0, 
      behavior: 'smooth' 
    });
    
    // If clicking on current page, prevent navigation (just scroll to top)
    if (isActive(path)) {
      e.preventDefault();
    }
  };

  // Handle scroll for navbar visibility
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      // Clear existing timeout
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
      
      // Show/hide based on scroll direction
      if (currentScrollY < lastScrollY || currentScrollY < 100) {
        // Scrolling up or near top - show navbar
        setIsVisible(true);
      } else if (currentScrollY > lastScrollY && currentScrollY > 100) {
        // Scrolling down and past threshold - hide navbar
        setIsVisible(false);
      }
      
      setLastScrollY(currentScrollY);
      
      // Set timeout to show navbar after scroll stops
      scrollTimeoutRef.current = setTimeout(() => {
        setIsVisible(true);
      }, 1000);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
    };
  }, [lastScrollY]);
  return (
    <>
      <header className={`bg-white/80 backdrop-blur-md shadow-lg sticky top-0 z-50 border-b border-gray-200/50 transition-all duration-300 ${
        isVisible ? 'transform translate-y-0 opacity-100' : 'transform -translate-y-full opacity-0'
      }`}>
        <div className="w-full max-w-none px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-24">
            {/* Logo - Left Side */}
            <Link to="/" onClick={(e) => handleNavClick('/', e)} className="hidden md:block flex-shrink-0">
              <img
                src="/grasse logo.png"
                alt="Grasse Logo"
                className="h-16 w-auto transition-opacity hover:opacity-80"
              />
            </Link>

            {/* Navigation - Center */}
            <nav className="hidden md:flex flex-1 items-center justify-center">
              <div className="flex items-center">
                {/* Navigation Links */}
                <div className="flex items-baseline space-x-4 lg:space-x-5">
                  <Link
                    to="/"
                    onClick={(e) => handleNavClick('/', e)}
                    className={`px-1 lg:px-2 py-3 text-sm lg:text-base font-medium transition-colors whitespace-nowrap ${
                      isActive('/')
                        ? 'text-gold-600 border-b-2 border-gold-600'
                        : 'text-gray-700 hover:text-gold-600'
                    }`}
                  >
                    Home
                  </Link>
                  <Link
                    to="/perfumes"
                    onClick={(e) => handleNavClick('/perfumes', e)}
                    className={`px-1 lg:px-2 py-3 text-sm lg:text-base font-medium transition-colors whitespace-nowrap ${
                      isActive('/perfumes')
                        ? 'text-gold-600 border-b-2 border-gold-600'
                        : 'text-gray-700 hover:text-gold-600'
                    }`}
                  >
                    Perfumes
                  </Link>
                  <Link
                    to="/incenses"
                    onClick={(e) => handleNavClick('/incenses', e)}
                    className={`px-1 lg:px-2 py-3 text-sm lg:text-base font-medium transition-colors whitespace-nowrap ${
                      isActive('/incenses')
                        ? 'text-gold-600 border-b-2 border-gold-600'
                        : 'text-gray-700 hover:text-gold-600'
                    }`}
                  >
                    Incenses
                  </Link>
                  <Link
                    to="/air-fresheners"
                    onClick={(e) => handleNavClick('/air-fresheners', e)}
                    className={`px-1 lg:px-2 py-3 text-sm lg:text-base font-medium transition-colors whitespace-nowrap ${
                      isActive('/air-fresheners')
                        ? 'text-gold-600 border-b-2 border-gold-600'
                        : 'text-gray-700 hover:text-gold-600'
                    }`}
                  >
                    Air Fresheners
                  </Link>
                  <Link
                    to="/ouds"
                    onClick={(e) => handleNavClick('/ouds', e)}
                    className={`px-1 lg:px-2 py-3 text-sm lg:text-base font-medium transition-colors whitespace-nowrap ${
                      isActive('/ouds')
                        ? 'text-gold-600 border-b-2 border-gold-600'
                        : 'text-gray-700 hover:text-gold-600'
                    }`}
                  >
                    Ouds
                  </Link>
                  <Link
                    to="/about-us"
                    onClick={(e) => handleNavClick('/about-us', e)}
                    className={`px-1 lg:px-2 py-3 text-sm lg:text-base font-medium transition-colors whitespace-nowrap ${
                      isActive('/about-us')
                        ? 'text-gold-600 border-b-2 border-gold-600'
                        : 'text-gray-700 hover:text-gold-600'
                    }`}
                  >
                    About Us
                  </Link>
                  <Link
                    to="/contact-us"
                    onClick={(e) => handleNavClick('/contact-us', e)}
                    className={`px-1 lg:px-2 py-3 text-sm lg:text-base font-medium transition-colors whitespace-nowrap ${
                      isActive('/contact-us')
                        ? 'text-gold-600 border-b-2 border-gold-600'
                        : 'text-gray-700 hover:text-gold-600'
                    }`}
                  >
                    Contact Us
                  </Link>
                  <Link
                    to="/fav"
                    onClick={(e) => handleNavClick('/fav', e)}
                    className={`px-1 lg:px-2 py-3 text-sm lg:text-base font-medium transition-colors flex items-center space-x-1 whitespace-nowrap ${
                      isActive('/fav')
                        ? 'text-gold-600 border-b-2 border-gold-600'
                        : 'text-gray-700 hover:text-gold-600'
                    }`}
                  >
                    <span>Fav</span>
                    <span>❤️</span>
                  </Link>
                </div>

                {/* Actions */}
                <div className="flex items-center space-x-3 lg:space-x-6 flex-shrink-0">
                  <div className="relative">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSearchToggle();
                      }}
                      className="p-2 lg:p-3 text-gray-600 hover:text-gold-600 transition-colors"
                    >
                      {isSearchOpen ? <X className="h-6 w-6" /> : <Search className="h-6 w-6" />}
                    </button>
                  </div>
                  <button
                    onClick={onCartClick}
                    className="relative p-2 lg:p-3 text-gray-600 hover:text-gold-600 transition-colors"
                  >
                    <ShoppingCart className="h-6 w-6" />
                    {cartItemsCount > 0 && (
                      <span className="absolute -top-1 -right-1 bg-gold-600 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center font-bold">
                        {cartItemsCount}
                      </span>
                    )}
                  </button>
                </div>
              </div>
            </nav>

            {/* Right Spacer for Balance */}
            <div className="hidden md:block flex-shrink-0" style={{ width: '160px' }}></div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center justify-between w-full px-4">
              <Link to="/" className="flex-shrink-0">
                <img
                  src="/grasse logo.png"
                  alt="Grasse Logo"
                  className="h-10 w-auto transition-opacity hover:opacity-80"
                />
              </Link>
              <div className="flex items-center space-x-3">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSearchToggle();
                  }}
                  className="p-2 text-gray-600 hover:text-gold-600 transition-colors"
                >
                  {isSearchOpen ? <X className="h-5 w-5" /> : <Search className="h-5 w-5" />}
                </button>
                <button 
                  onClick={onCartClick}
                  className="relative p-2 text-gray-600 hover:text-gold-600 transition-colors"
                >
                  <ShoppingCart className="h-5 w-5" />
                  {cartItemsCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-gold-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold">
                      {cartItemsCount}
                    </span>
                  )}
                </button>
                <button className="p-2 text-gray-600 hover:text-gold-600 transition-colors">
                  <Menu className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Search Overlay */}
      {isSearchOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center pt-20 px-4">
          <div 
            className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl border border-gray-200"
            onClick={(e) => e.stopPropagation()}
          >
            <form onSubmit={handleSearchSubmit} className="p-6">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search pages and products..."
                  className="w-full pl-12 pr-4 py-4 text-lg border border-gray-300 rounded-xl focus:outline-none focus:border-gold-600 transition-colors"
                  autoFocus
                />
              </div>
            </form>

            {/* Search Results */}
            {searchQuery.trim() && (
              <div className="border-t border-gray-200 max-h-96 overflow-y-auto">
                {filteredResults.length > 0 ? (
                  <div className="py-2">
                    {filteredResults.map((result, index) => (
                      <button
                        key={index}
                        onClick={() => handleSearchClick(result.path)}
                        className="w-full text-left px-6 py-3 hover:bg-gray-50 transition-colors flex items-center justify-between"
                      >
                        <div>
                          <div className="font-medium text-gray-900">{result.title}</div>
                          <div className="text-sm text-gray-500 capitalize">{result.type}</div>
                        </div>
                        <Search className="h-4 w-4 text-gray-400" />
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="py-8 text-center text-gray-500">
                    No results found for "{searchQuery}"
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default Header;