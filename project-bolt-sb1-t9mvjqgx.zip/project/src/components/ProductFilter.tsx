import React from 'react';
import { Filter, X } from 'lucide-react';

export interface FilterOptions {
  priceRange: [number, number];
  gender: 'all' | 'men' | 'women' | 'unisex';
  sortBy: 'name' | 'price-low' | 'price-high' | 'rating';
}

interface ProductFilterProps {
  filters: FilterOptions;
  onFiltersChange: (filters: FilterOptions) => void;
  isOpen: boolean;
  onToggle: () => void;
  productCount: number;
}

const ProductFilter: React.FC<ProductFilterProps> = ({
  filters,
  onFiltersChange,
  isOpen,
  onToggle,
  productCount
}) => {
  const handlePriceChange = (type: 'min' | 'max', value: string) => {
    const numValue = parseFloat(value) || 0;
    const newRange: [number, number] = [...filters.priceRange];
    if (type === 'min') {
      newRange[0] = numValue;
    } else {
      newRange[1] = numValue;
    }
    onFiltersChange({ ...filters, priceRange: newRange });
  };

  const resetFilters = () => {
    onFiltersChange({
      priceRange: [0, 200],
      gender: 'all',
      sortBy: 'name'
    });
  };

  return (
    <div className="relative">
      {/* Filter Toggle Button */}
      <button
        onClick={onToggle}
        className="flex items-center space-x-2 bg-white border border-gray-300 px-4 py-3 rounded-full hover:border-gold-600 transition-colors"
      >
        <Filter className="h-5 w-5 text-gray-600" />
        <span className="text-gray-700 font-medium">Filters</span>
        <span className="bg-gold-600 text-white text-xs px-2 py-1 rounded-full">
          {productCount}
        </span>
      </button>

      {/* Filter Panel */}
      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-72 bg-white border border-gray-200 rounded-2xl shadow-xl z-50 p-5">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-gray-900">Filters</h3>
            <button
              onClick={onToggle}
              className="p-1 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="h-5 w-5 text-gray-500" />
            </button>
          </div>

          {/* Price Range */}
          <div className="mb-6">
            <h4 className="font-semibold text-gray-900 mb-3">Price Range</h4>
            <div className="flex items-center space-x-3">
              <div className="flex-1">
                <label className="block text-sm text-gray-600 mb-1">Min</label>
                <input
                  type="number"
                  value={filters.priceRange[0]}
                  onChange={(e) => handlePriceChange('min', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-gold-600"
                  placeholder="0"
                />
              </div>
              <span className="text-gray-400 mt-6">-</span>
              <div className="flex-1">
                <label className="block text-sm text-gray-600 mb-1">Max</label>
                <input
                  type="number"
                  value={filters.priceRange[1]}
                  onChange={(e) => handlePriceChange('max', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-gold-600"
                  placeholder="200"
                />
              </div>
            </div>
          </div>

          {/* Gender Filter */}
          <div className="mb-6">
            <h4 className="font-semibold text-gray-900 mb-3">Gender</h4>
            <div className="space-y-2">
              {[
                { value: 'all', label: 'All' },
                { value: 'men', label: 'Men' },
                { value: 'women', label: 'Women' },
                { value: 'unisex', label: 'Unisex' }
              ].map((option) => (
                <label key={option.value} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="radio"
                    name="gender"
                    value={option.value}
                    checked={filters.gender === option.value}
                    onChange={(e) => onFiltersChange({ ...filters, gender: e.target.value as any })}
                    className="text-gold-600 focus:ring-gold-600"
                  />
                  <span className="text-gray-700">{option.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Sort By */}
          <div className="mb-6">
            <h4 className="font-semibold text-gray-900 mb-3">Sort By</h4>
            <select
              value={filters.sortBy}
              onChange={(e) => onFiltersChange({ ...filters, sortBy: e.target.value as any })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-gold-600"
            >
              <option value="name">Name (A-Z)</option>
              <option value="price-low">Price (Low to High)</option>
              <option value="price-high">Price (High to Low)</option>
              <option value="rating">Rating (High to Low)</option>
            </select>
          </div>

          {/* Actions */}
          <div className="flex space-x-3">
            <button
              onClick={resetFilters}
              className="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Reset
            </button>
            <button
              onClick={onToggle}
              className="flex-1 bg-gradient-to-r from-gold-600 to-gold-700 text-white py-2 rounded-lg hover:from-gold-700 hover:to-gold-800 transition-all"
            >
              Apply
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductFilter;