import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Heart } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  image: string;
  images?: string[];
  description: string;
  rating: number;
  gender?: 'men' | 'women' | 'unisex';
  priceRange?: 'budget' | 'mid' | 'luxury';
}

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onToggleFavorite?: (product: Product) => void;
  isFavorite?: (productId: number) => boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onToggleFavorite, isFavorite }) => {
  const [cardRef, isVisible] = useScrollAnimation(0.2);
  const [currentImageIndex, setCurrentImageIndex] = React.useState(0);

  const discountPercentage = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const isProductFavorite = isFavorite ? isFavorite(product.id) : false;

  const displayImage = product.images && product.images.length > 1 && currentImageIndex === 1
    ? product.images[1]
    : product.image;
  return (
    <div 
      ref={cardRef}
      className={`group relative bg-#ffffff rounded-2xl shadow-sm hover:shadow-xl transition-all duration-700 transform hover:-translate-y-2 overflow-hidden border border-gray-200 ${
        isVisible 
          ? 'opacity-100 translate-y-0 scale-100' 
          : 'opacity-0 translate-y-8 scale-95'
      }`}
    >
      {discountPercentage > 0 && (
        <div className="absolute top-4 left-4 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-semibold z-10">
          -{discountPercentage}%
        </div>
      )}
      
      {onToggleFavorite && (
        <button 
          onClick={() => onToggleFavorite(product)}
          className={`absolute top-4 right-4 p-2 rounded-full transition-all z-10 shadow-md ${
            isProductFavorite 
              ? 'bg-red-50 opacity-100' 
              : 'bg-white/90 opacity-0 group-hover:opacity-100 hover:bg-red-50'
          }`}
        >
          <Heart className={`h-4 w-4 transition-colors ${
            isProductFavorite 
              ? 'text-red-500 fill-red-500' 
              : 'text-gray-400 hover:text-red-500'
          }`} />
        </button>
      )}

      <Link to={`/product/${product.id}`} className="block">
        <div
          className="aspect-square overflow-hidden bg-gradient-to-br from-gray-100 to-amber-50 relative"
          onMouseEnter={() => product.images && product.images.length > 1 && setCurrentImageIndex(1)}
          onMouseLeave={() => setCurrentImageIndex(0)}
        >
          <img
            src={product.image}
            alt={product.name}
            className={`w-full h-full object-cover group-hover:scale-105 transition-all duration-700 absolute inset-0 ${
              currentImageIndex === 0 ? 'opacity-100' : 'opacity-0'
            }`}
          />
          {product.images && product.images.length > 1 && (
            <img
              src={product.images[1]}
              alt={product.name}
              className={`w-full h-full object-cover group-hover:scale-105 transition-all duration-700 absolute inset-0 ${
                currentImageIndex === 1 ? 'opacity-100' : 'opacity-0'
              }`}
            />
          )}
        </div>
      </Link>

      <div className="p-6">
        <div className="mb-2">
          <span className="text-xs font-semibold text-gold-600 uppercase tracking-wider bg-gold-50 px-2 py-1 rounded-full border border-gold-200">
            {product.category}
          </span>
        </div>

        <Link to={`/product/${product.id}`}>
          <h3 className="font-bold text-gray-900 mb-2 text-lg group-hover:text-gold-600 transition-colors">
            {product.name}
          </h3>
        </Link>

        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {product.description}
        </p>

        <div className="flex items-center mb-4">
          {[...Array(5)].map((_, i) => (
            <svg
              key={i}
              className={`h-4 w-4 ${
                i < Math.floor(product.rating) 
                  ? 'text-gold-500' 
                  : 'text-gray-300'
              }`}
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
          ))}
          <span className="ml-1 text-sm text-gold-600">({product.rating})</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-2xl" style={{ color: '#111827' }}>
              {product.price} AED
            </span>
            {product.originalPrice && (
              <span className="text-sm text-gray-400 line-through">
                {product.originalPrice} AED
              </span>
            )}
          </div>
          
          <button
            onClick={() => onAddToCart(product)}
            className="bg-gradient-to-r from-gold-600 to-gold-700 text-white px-4 py-2.5 rounded-full hover:from-gold-700 hover:to-gold-800 transition-all flex items-center space-x-2 transform hover:scale-105 shadow-lg hover:shadow-gold-600/25"
          >
            <ShoppingCart className="h-4 w-4" />
            <span className="text-sm font-semibold">Add</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;