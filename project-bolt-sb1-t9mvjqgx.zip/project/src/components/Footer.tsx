import React from 'react';
import { Instagram, Facebook, Twitter, Mail, Phone, MapPin } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import StarField from './StarField';

const Footer: React.FC = () => {
  const [footerRef, isVisible] = useScrollAnimation(0.1);

  return (
    <footer 
      ref={footerRef}
      className={`bg-gray-900 text-white transition-all duration-1000 border-t border-gray-200 ${
        isVisible 
          ? 'opacity-100 transform translate-y-0' 
          : 'opacity-0 transform translate-y-12'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <img
              src="/grasse logo.png"
              alt="Grasse Logo"
              className="h-16 w-auto mb-4"
            />
            <p className="text-gray-400 mb-6">
              Crafting luxury fragrances that define elegance and sophistication.
              Your signature scent awaits.
            </p>
            <div className="flex space-x-4">
              <button className="p-2 bg-gray-800 hover:bg-gold-500 rounded-full transition-colors border border-gold-500/20 hover:border-gold-500">
                <Instagram className="h-5 w-5" />
              </button>
              <button className="p-2 bg-gray-800 hover:bg-gold-500 rounded-full transition-colors border border-gold-500/20 hover:border-gold-500">
                <Facebook className="h-5 w-5" />
              </button>
              <button className="p-2 bg-gray-800 hover:bg-gold-500 rounded-full transition-colors border border-gold-500/20 hover:border-gold-500">
                <Twitter className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4 text-gold-400">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#perfumes" className="text-gray-400 hover:text-gold-400 transition-colors">Perfumes</a></li>
              <li><a href="#incenses" className="text-gray-400 hover:text-gold-400 transition-colors">Incenses</a></li>
              <li><a href="#fresheners" className="text-gray-400 hover:text-gold-400 transition-colors">Air Fresheners</a></li>
              <li><a href="#about" className="text-gray-400 hover:text-gold-400 transition-colors">About Us</a></li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="font-semibold mb-4 text-gold-400">Customer Service</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-gold-400 transition-colors">Contact Us</a></li>
              <li><a href="#" className="text-gray-400 hover:text-gold-400 transition-colors">Shipping Info</a></li>
              <li><a href="#" className="text-gray-400 hover:text-gold-400 transition-colors">Returns</a></li>
              <li><a href="#" className="text-gray-400 hover:text-gold-400 transition-colors">FAQ</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold mb-4 text-gold-400">Contact Info</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <MapPin className="h-4 w-4 text-gold-400" />
                <span className="text-gray-400 text-sm">123 Fragrance Ave, NY 10001</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-gold-400" />
                <span className="text-gray-400 text-sm">(555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-gold-400" />
                <span className="text-gray-400 text-sm">hello@elegance.com</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-400">
            © 2025 Grasse. All rights reserved. Crafted with passion for luxury fragrances.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;