import React from 'react';
import { Link } from 'react-router-dom';
import { X, Plus, Minus, ShoppingBag, ShoppingCart } from 'lucide-react';
import { Product } from './ProductCard';

interface CartItem extends Product {
  quantity: number;
}

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: number, quantity: number) => void;
  onRemoveItem: (id: number) => void;
}

const Cart: React.FC<CartProps> = ({ 
  isOpen, 
  onClose, 
  items, 
  onUpdateQuantity, 
  onRemoveItem 
}) => {
  const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden pointer-events-none">
      <div 
        className="absolute inset-0 bg-black bg-opacity-50 pointer-events-auto" 
        onClick={onClose}
      ></div>
      
      <div className="absolute right-0 top-0 h-full w-96 bg-white shadow-xl border-l border-gray-200 pointer-events-auto transform transition-transform duration-300 ease-in-out">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-white">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-gold-600 to-gold-700 rounded-full flex items-center justify-center">
                <ShoppingCart className="h-5 w-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gold-600">
                  Shopping Cart
                </h2>
                <p className="text-sm text-gray-500">{itemCount} {itemCount === 1 ? 'item' : 'items'}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-500 hover:text-gold-600"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Items */}
          <div className="flex-1 overflow-y-auto p-6 bg-white">
            {items.length === 0 ? (
              <div className="text-center py-12">
                <ShoppingBag className="h-16 w-16 text-gold-600 mx-auto mb-4" />
                <p className="text-gold-600 text-lg font-semibold">Your cart is empty</p>
                <p className="text-gray-500 text-sm mt-2">Add some beautiful fragrances to get started</p>
              </div>
            ) : (
              <div className="space-y-6">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-xl border border-gray-200 hover:border-gold-200 transition-colors group">
                    <Link to={`/product/${item.id}`} onClick={onClose} className="flex-shrink-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-16 h-16 object-cover rounded-lg bg-gray-100 group-hover:scale-105 transition-transform cursor-pointer"
                      />
                    </Link>

                    <div className="flex-1 min-w-0">
                      <Link to={`/product/${item.id}`} onClick={onClose}>
                        <h3 className="font-medium text-gray-900 truncate hover:text-gold-600 transition-colors cursor-pointer">
                          {item.name}
                        </h3>
                      </Link>
                      <p className="text-sm text-gold-600 font-medium">{item.category}</p>
                      <p className="font-bold text-gray-900">{item.price} AED</p>
                    </div>

                    <div className="flex items-center space-x-2 flex-shrink-0">
                      <button
                        onClick={() => onUpdateQuantity(item.id, Math.max(0, item.quantity - 1))}
                        className="p-1 hover:bg-gray-100 rounded transition-colors text-gray-500 hover:text-gold-600"
                      >
                        <Minus className="h-4 w-4" />
                      </button>
                      
                      <span className="w-8 text-center font-medium text-gray-900">
                        {item.quantity}
                      </span>
                      
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                        className="p-1 hover:bg-gray-100 rounded transition-colors text-gray-500 hover:text-gold-600"
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>

                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="p-1 hover:bg-red-50 rounded transition-colors text-red-500 hover:text-red-600"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          {items.length > 0 && (
            <div className="border-t border-gray-200 p-6 space-y-4 bg-white">
              <div className="flex justify-between items-center text-lg font-bold">
                <span style={{ color: '#111827' }}>Total:</span>
                <span style={{ color: '#111827' }}>{total.toFixed(2)} AED</span>
              </div>
              
              <button className="w-full bg-gradient-to-r from-gold-600 to-gold-700 text-white py-3 rounded-full font-semibold hover:from-gold-700 hover:to-gold-800 transition-all transform hover:scale-105 shadow-lg hover:shadow-gold-600/25">
                Proceed to Checkout
              </button>
              
              <button 
                onClick={onClose}
                className="w-full border-2 border-gray-300 text-gray-600 py-3 rounded-full font-semibold hover:bg-gray-50 hover:text-gold-600 transition-colors"
              >
                Continue Shopping
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Cart;