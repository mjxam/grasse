import React, { useEffect, useState } from 'react';

const LoadingScreen: React.FC<{ onLoadingComplete: () => void }> = ({ onLoadingComplete }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onLoadingComplete, 200); // Small delay before revealing content
          return 100;
        }
        return prev + 4; // Increase by 4% every 40ms = 1 second total
      });
    }, 40);

    return () => clearInterval(interval);
  }, [onLoadingComplete]);

  return (
    <div className="fixed inset-0 bg-#ffffff flex items-center justify-center z-50">
      <div className="text-center">
        <div className="mb-8 flex justify-center">
          <img
            src="/grasse logo.png"
            alt="Grasse Logo"
            className="h-32 w-auto animate-pulse"
          />
        </div>
        
        <div className="w-64 h-1 bg-gray-200 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-gold-600 to-gold-700 rounded-full transition-all duration-100 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        
        <p className="text-gray-600 mt-4 text-sm tracking-wider">
          Loading luxury fragrances...
        </p>
      </div>
    </div>
  );
};

export default LoadingScreen;