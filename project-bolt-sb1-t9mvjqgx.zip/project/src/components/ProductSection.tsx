import React from 'react';
import ProductCard, { Product } from './ProductCard';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

interface ProductSectionProps {
  id: string;
  title: string;
  description: string;
  products: Product[];
  onAddToCart: (product: Product) => void;
  onToggleFavorite?: (product: Product) => void;
  isFavorite?: (productId: number) => boolean;
  maxProducts?: number;
}

const ProductSection: React.FC<ProductSectionProps> = ({
  id,
  title,
  description,
  products,
  onAddToCart,
  onToggleFavorite,
  isFavorite,
  maxProducts
}) => {
  const [sectionRef, isSectionVisible] = useScrollAnimation(0.1);
  const [gridRef, isGridVisible] = useScrollAnimation(0.05);

  const displayedProducts = maxProducts ? products.slice(0, maxProducts) : products;

  return (
    <section id={id} className="bg-gray-50 py-20" ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`text-center mb-16 transition-all duration-1000 ${
          isSectionVisible
            ? 'opacity-100 transform translate-y-0'
            : 'opacity-0 transform translate-y-8'
        }`}>
          <h2 className="text-4xl font-bold text-gold-600 mb-4">
            {title}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {description}
          </p>
        </div>

        <div
          ref={gridRef}
          className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 transition-all duration-1000 delay-300 ${
            isGridVisible
              ? 'opacity-100 transform translate-y-0'
              : 'opacity-0 transform translate-y-12'
          }`}
        >
          {displayedProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={onAddToCart}
              onToggleFavorite={onToggleFavorite}
              isFavorite={isFavorite}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductSection;