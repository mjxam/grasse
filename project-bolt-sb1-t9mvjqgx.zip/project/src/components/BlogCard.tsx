import React from 'react';
import { Calendar, Clock, User, Tag } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { BlogPost } from '../data/blogs';

interface BlogCardProps {
  blog: BlogPost;
  onReadMore: (blog: BlogPost) => void;
}

const BlogCard: React.FC<BlogCardProps> = ({ blog, onReadMore }) => {
  const [cardRef, isVisible] = useScrollAnimation(0.2);

  return (
    <article 
      ref={cardRef}
      className={`group bg-#ffffff rounded-2xl shadow-sm hover:shadow-xl transition-all duration-700 transform hover:-translate-y-2 overflow-hidden border border-gray-200 ${
        isVisible 
          ? 'opacity-100 translate-y-0 scale-100' 
          : 'opacity-0 translate-y-8 scale-95'
      }`}
    >
      <div className="aspect-video overflow-hidden bg-gradient-to-br from-gray-100 to-amber-50">
        <img 
          src={blog.image} 
          alt={blog.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
      </div>

      <div className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-xs font-semibold text-gold-600 uppercase tracking-wider bg-gold-50 px-2 py-1 rounded-full border border-gold-200">
            {blog.category}
          </span>
        </div>
        
        <h3 className="font-bold text-gray-900 mb-3 text-xl group-hover:text-gold-600 transition-colors line-clamp-2">
          {blog.title}
        </h3>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-3">
          {blog.excerpt}
        </p>

        <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <User className="h-3 w-3" />
              <span>{blog.author}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Calendar className="h-3 w-3" />
              <span>{new Date(blog.date).toLocaleDateString()}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Clock className="h-3 w-3" />
              <span>{blog.readTime}</span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-1 mb-4">
          {blog.tags.slice(0, 3).map((tag) => (
            <span 
              key={tag}
              className="inline-flex items-center text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded-full"
            >
              <Tag className="h-2 w-2 mr-1" />
              {tag}
            </span>
          ))}
        </div>

        <button
          onClick={() => onReadMore(blog)}
          className="w-full bg-gradient-to-r from-gold-600 to-gold-700 text-white py-3 rounded-full hover:from-gold-700 hover:to-gold-800 transition-all font-semibold transform hover:scale-105 shadow-lg hover:shadow-gold-600/25"
        >
          Read More
        </button>
      </div>
    </article>
  );
};

export default BlogCard;